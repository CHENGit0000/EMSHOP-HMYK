<?php
/**
 * global
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once '../init.php';

$sta_cache = $CACHE->readCache('sta');
$user_cache = $CACHE->readCache('user');
$action = Input::getStrVar('action');

if(isset($user_cache[UID]['role'])){
	$role = $user_cache[UID]['role'];
	$role_name = User::getRoleName($role, UID);

    $user = [
        'nickname' => $user_cache[UID]['name'],
        'avatar' => User::getAvatar($user_cache[UID]['avatar']),
    ];
}


//d($role_name);die;

loginAuth::checkLogin(NULL, 'admin');


User::checkRolePermission();


