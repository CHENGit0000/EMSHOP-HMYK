<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

$goodsModel = new Goods_Model();
$stockModel = new Stock_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

if (empty($action)) {
	
	$page = Input::getIntVar('page', 1);

    $stockNum = $stockModel->getStockNum();

    $list = $stockModel->getStockForAdmin($page);

    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($stockNum, Option::get('admin_article_perpage_num'), $page, "stock.php?{$subPage}&page=");

    $br = '<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">控制台</a></li>
        <li class="breadcrumb-item"><a href="./goods.php">商品管理</a></li>
        <li class="breadcrumb-item active" aria-current="page">库存管理</li>
    </ol>';

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once View::getAdmView('stock');
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action == 'del') {
    $stock_id = Input::getIntVar('stock_id');

    LoginAuth::checkToken();

    $stockModel->deleteStock("id={$stock_id}");

    emDirect("./stock.php?&active_del=1");
}


if ($action === 'add') {
    $goods_id = Input::postIntVar('goods_id', null);
    if($goods_id){
        $timestamp = time();

//        d($_POST);die;

        $goods = $goodsModel->getOneGoodsForAdmin($goods_id);
        $skus = Input::postStrArray('skus');

        if($goods['is_sku'] == 'n'){
            if($goods['type'] == 'guding'){ // 固定卡密

                $is_stock = $stockModel->isStock(Input::postIntVar('goods_id'), '0');
                if($is_stock){
                    $update = [
                        'content' => Input::postStrVar('content', null),
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->updateStock($update, $goods_id, '0');

                }else{
                    $insert = [
                        'goods_id' => Input::postIntVar('goods_id'),
                        'sku' => '0',
                        'content' => Input::postStrVar('content', null),
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->addStock($insert);
                }

            }
            if($goods['type'] == 'xuni'){ // 虚拟服务
                $is_stock = $stockModel->isStock(Input::postIntVar('goods_id'), '0');
                if($is_stock){
                    $update = [
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->updateStock($update, $goods_id, '0');

                }else{
                    $insert = [
                        'goods_id' => Input::postIntVar('goods_id'),
                        'sku' => '0',
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->addStock($insert);
                }
            }
            if($goods['type'] == 'post'){ // 自定义访问接口
                $is_stock = $stockModel->isStock(Input::postIntVar('goods_id'), '0');
                if($is_stock){
                    $update = [
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->updateStock($update, $goods_id, '0');

                }else{
                    $insert = [
                        'goods_id' => Input::postIntVar('goods_id'),
                        'sku' => '0',
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->addStock($insert);
                }
            }
            if($goods['type'] == 'duli'){ // 独立卡密
                $stock = Input::postStrVar('content');
                $stock = array_filter(explode("\r\n", $stock));
                if(!empty($stock)){
                    foreach($stock as $v){
                        $insert = [
                            'goods_id' => Input::postStrVar('goods_id'),
                            'sku' => '0',
                            'content' => $v,
                            'create_time' => $timestamp,
                            'quantity' => 1,
                        ];
                        $stockModel->addStock($insert);
                    }
                }
            }
        }
        if($goods['is_sku'] == 'y'){
            $sku = Input::postStrVar('sku');
            if($goods['type'] == 'duli'){
                $stock = Input::postStrVar('content');
                $stock = array_filter(explode("\r\n", $stock));
                if(!empty($stock)){
                    foreach($stock as $v){
                        $insert = [
                            'goods_id' => Input::postStrVar('goods_id'),
                            'sku' => $sku,
                            'content' => $v,
                            'create_time' => $timestamp,
                            'quantity' => 1,
                        ];
                        $stockModel->addStock($insert);
                    }
                }
            }
            if($goods['type'] == 'guding'){
                $sku = Input::postStrVar('sku');
                $is_stock = $stockModel->isStock(Input::postIntVar('goods_id'), $sku);
                if($is_stock){
                    $update = [
                        'content' => Input::postStrVar('content', null),
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->updateStock($update, $goods_id, $sku);

                }else{
                    $insert = [
                        'goods_id' => Input::postIntVar('goods_id'),
                        'sku' => $sku,
                        'content' => Input::postStrVar('content', null),
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->addStock($insert);
                }
            }
            if($goods['type'] == 'xuni'){
                $sku = Input::postStrVar('sku');
                $is_stock = $stockModel->isStock(Input::postIntVar('goods_id'), $sku);
                if($is_stock){
                    $update = [
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->updateStock($update, $goods_id, $sku);

                }else{
                    $insert = [
                        'goods_id' => Input::postIntVar('goods_id'),
                        'sku' => $sku,
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->addStock($insert);
                }
            }
            if($goods['type'] == 'post'){
                $sku = Input::postStrVar('sku');
                $is_stock = $stockModel->isStock(Input::postIntVar('goods_id'), $sku);
                if($is_stock){
                    $update = [
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->updateStock($update, $goods_id, $sku);

                }else{
                    $insert = [
                        'goods_id' => Input::postIntVar('goods_id'),
                        'sku' => $sku,
                        'create_time' => $timestamp,
                        'quantity' => Input::postIntVar('quantity', 0),
                    ];
                    $stockModel->addStock($insert);
                }
            }
        }


        emDirect("./stock.php?&action=add&goods_id={$goods_id}&save=1");
    }


    $goods_id = Input::getIntVar('goods_id', -1);
    $goods = $goodsModel->getOneGoodsForAdmin($goods_id);
//    d($goods);die;
    $db = Database::getInstance();
    if($goods['is_sku'] == 'y'){
        $get_sku = Input::getStrVar('get_sku', null);
        $sql = "select * from " . DB_PREFIX . "skus where goods_id={$goods['id']}";
        $result = $db->fetch_all($sql);
        $data = [];
        foreach($result as $key => $val){
            $sku_values = explode('-', $val['sku']);
            $data[$key]['sku_name'] = '';
            $data[$key]['sku_value'] = $val['sku'];
            foreach($sku_values as $v){
                $sql = "select * from " . DB_PREFIX . "sku_value where id={$v}";
                $sku_value = $db->once_fetch_array($sql);
                $data[$key]['sku_name'] .= $sku_value['name'] . '-';
            }
            $data[$key]['sku_name'] = rtrim($data[$key]['sku_name'], '-');
        }
        if($goods['type'] == 'guding'){
            $sql = "SELECT * FROM `" . DB_PREFIX . "stock` where goods_id={$goods['id']} and sku='{$get_sku}' limit 1;";
            $stock = $db->once_fetch_array($sql);
        }
        if($goods['type'] == 'xuni'){
            $sql = "SELECT * FROM `" . DB_PREFIX . "stock` where goods_id={$goods['id']} and sku='{$get_sku}' limit 1;";
            $stock = $db->once_fetch_array($sql);
        }
        if($goods['type'] == 'post'){
            $sql = "SELECT * FROM `" . DB_PREFIX . "stock` where goods_id={$goods['id']} and sku='{$get_sku}' limit 1;";
            $stock = $db->once_fetch_array($sql);
        }
//        d($data);die;
    }else{
        $sql = "SELECT * FROM `" . DB_PREFIX . "skus` where goods_id={$goods['id']} and sku='0' limit 1;";
        $skus = $db->once_fetch_array($sql);
        if($goods['type'] == 'xuni'){
            $sql = "SELECT * FROM `" . DB_PREFIX . "stock` where goods_id={$goods['id']} and sku='0' limit 1;";
            $stock = $db->once_fetch_array($sql);
        }
        if($goods['type'] == 'guding'){
            $sql = "SELECT * FROM `" . DB_PREFIX . "stock` where goods_id={$goods['id']} and sku='0' limit 1;";
            $stock = $db->once_fetch_array($sql);
        }
        if($goods['type'] == 'post'){
            $sql = "SELECT * FROM `" . DB_PREFIX . "stock` where goods_id={$goods['id']} and sku='0' limit 1;";
            $stock = $db->once_fetch_array($sql);
        }

    }


    $br = '<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">控制台</a></li>
        <li class="breadcrumb-item"><a href="./goods.php">商品管理</a></li>
        <li class="breadcrumb-item"><a href="./stock.php">库存管理</a></li>
        <li class="breadcrumb-item active" aria-current="page">添加库存 - ' . $goods['title'] . '</li>
    </ol>';



    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once(View::getAdmView('stock_add'));
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action === 'edit') {
    $goods_id = Input::getIntVar('id');

    $goodsModel->checkEditable($goods_id);
    $blogData = $goodsModel->getOneProductForAdmin($goods_id);
    extract($blogData);

    $isdraft = $hide == 'y' ? true : false;
    $postsName = User::isAdmin() ? '商品' : Option::get('posts_name');
    $containerTitle = $isdraft ? '编辑草稿' : '编辑' . $postsName;
    $postDate = date('Y-m-d H:i', $date);
    $sorts = $CACHE->readCache('sort');



    $mediaSorts = $MediaSort_Model->getSorts();

    $customTemplates = $Template_Model->getCustomTemplates('log');

    $is_top = $top == 'y' ? 'checked="checked"' : '';
    $is_sortop = $sortop == 'y' ? 'checked="checked"' : '';

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once(View::getAdmView('stock_add'));
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}