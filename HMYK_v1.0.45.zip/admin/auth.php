<?php
/**
 * register emlog
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

if (empty($action)) {

    $br = '<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">控制台</a></li>
        <li class="breadcrumb-item active" aria-current="page">正版授权<span id="save_info"></span></li>
    </ol>
    ';

    include View::getAdmView('header');
    require_once(View::getAdmView('auth'));
    include View::getAdmView('footer');
    View::output();
}

if ($action === 'auth') {

    $emkey = Input::postStrVar('emkey');


    if (empty($emkey)) {
        emDirect("./auth.php?error_b=1");
    }


    $r = Register::doReg($emkey);


    if ($r === false) {
        emDirect("./auth.php?error_b=1");
    }


    if (isset($r['data']['type'])) {
        Option::updateOption("emkey_type", $r['data']['type']);
    }
    Option::updateOption("emkey", $emkey);
    $CACHE->updateCache('options');
    emDirect("./auth.php");
}
