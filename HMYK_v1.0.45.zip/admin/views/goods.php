<?php
defined('EM_ROOT') || exit('access denied!');
?>

<style>
    /* 自定义表格样式 */
    .table-container {
        margin: 20px auto;
        max-width: 1200px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 1px solid #f0f0f0;
    }

    .table-header h3 {
        margin: 0;
        color: #333;
        font-weight: 600;
    }

    .search-box {
        position: relative;
        width: 240px;
    }

    .search-box input {
        padding-left: 35px;
        border-radius: 20px;
        border: 1px solid #ddd;
        transition: all 0.3s ease;
    }

    .search-box input:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .search-box .fa-search {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #999;
    }

    .table-responsive {
        padding: 20px;
    }

    /* 表格样式优化 */
    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table thead th {
        background-color: #f8f9fa;
        color: #555;
        font-weight: 600;
        border-bottom: 2px solid #e9ecef;
        padding: 12px 15px;
        text-align: left;
    }

    .custom-table tbody td {
        padding: 12px 15px;
        border-bottom: 1px solid #f2f2f2;
        transition: background-color 0.2s ease;
    }

    .custom-table tbody tr:hover {
        background-color: #f9f9f9;
    }

    /* 按钮样式 */
    .btn-action {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 14px;
        transition: all 0.2s ease;
    }

    .btn-edit {
        background-color: #4CAF50;
        color: white;
        margin-right: 5px;
    }

    .btn-edit:hover {
        background-color: #45a049;
        color: white;
    }

    .btn-delete {
        background-color: #f44336;
        color: white;
    }

    .btn-delete:hover {
        background-color: #da190b;
        color: white;
    }

    /* 新增按钮样式 */
    .btn-add {
        background-color: #007bff;
        color: white;
        margin-right: 10px;
    }

    .btn-add:hover {
        background-color: #0069d9;
        color: white;
    }

    /* 批量删除按钮样式 */
    .btn-batch-delete {
        background-color: #dc3545;
        color: white;
    }

    .btn-batch-delete:hover {
        background-color: #c82333;
        color: white;
    }

    .btn-batch-delete:disabled {
        background-color: #e2e3e5;
        color: #737373;
        cursor: not-allowed;
    }

    /* 分页样式 */
    .pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        border-top: 1px solid #f0f0f0;
    }

    .pagination {
        margin: 0;
    }

    .pagination li a {
        color: #007bff;
        border: 1px solid #ddd;
        padding: 6px 12px;
        margin-left: -1px;
        transition: all 0.2s ease;
    }

    .pagination li a:hover {
        background-color: #f2f2f2;
    }

    .pagination li.active a {
        background-color: #007bff;
        color: white;
        border-color: #007bff;
    }

    /* 模态框样式 */
    .modal-content {
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .modal-title {
        font-weight: 600;
        color: #333;
    }

    .modal-footer {
        border-top: 1px solid #e9ecef;
    }

    /* 响应式调整 */
    @media (max-width: 768px) {
        .table-header {
            flex-direction: column;
            align-items: flex-start;
        }

        .search-box {
            margin-top: 15px;
            width: 100%;
        }

        .pagination-container {
            flex-direction: column;
        }

        .pagination-info {
            margin-bottom: 15px;
        }
    }



    /* 自定义模态框宽度 */
    .modal-dialog-custom {
        max-width: 90%;
        width: auto;
    }

    /* 小屏幕设备优化 */
    @media (max-width: 768px) {
        .modal-dialog-custom {
            max-width: 95%;
        }
    }

    /* 确保按钮在最上层 */
    .modal-footer .btn {
        position: relative;
        z-index: 1050; /* 确保按钮在模态框的z-index之上 */
    }

    /* 修改模态框动画为淡入淡出 */
    .modal.fade .modal-dialog {
        transition: transform 0.2s ease-out, opacity 0.2s ease-out;
        transform: translate(0, 0) scale(0.95);
        opacity: 0;
    }

    .modal.show .modal-dialog {
        transform: translate(0, 0) scale(1);
        opacity: 1;
    }

    /* 背景遮罩淡入淡出 */
    .modal-backdrop.fade {
        opacity: 0;
    }

    .modal-backdrop.show {
        opacity: 0.1;
    }
</style>



<div>
    <div class="table-container">
        <div style="padding: 12px 10px;">
            <div class="btn-group">
                <a href="./goods.php?action=release" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> 发布商品</a>
            </div>
        </div>

        <form action="goods.php?action=operate_goods" method="post" name="form_log" id="form_log">
            <div class="">
                <table class="table table-striped table-hover scrollable-table">
                    <thead>
                    <tr>
                        <th style="width: 30px"><input type="checkbox" id="checkAllItem"/></th>
                        <th class="text-center">封面图</th>
                        <th style="min-width: 200px">商品名称</th>
                        <th class="text-center" style="min-width: 120px">商品类型</th>
                        <th class="text-center" style="min-width: 120px">库存</th>
                        <th class="text-center" style="min-width: 120px">分类</th>
                        <th class="text-center" style="min-width: 50px">上架</th>
                        <th class="text-center" style="min-width: 50px">销量</th>
                        <th class="text-center" style="min-width: 140px">添加时间</th>
                        <th class="text-center" style="min-width: 170px">操作</th>
                    </tr>
                    </thead>
                    <tbody class="checkboxContainer">
                    <?php
                    $multiCheckBtn = false; // 是否显示批量审核驳回按钮
                    foreach ($goods as $key => $value):
                        $sortName = isset($sorts[$value['sort_id']]['sortname']) ? $sorts[$value['sort_id']]['sortname'] : '未知分类';
                        $sortName = $value['sort_id'] == -1 ? '未分类' : $sortName;
                        ?>
                        <tr>
                            <td style="width: 20px;"><input type="checkbox" name="blog[]" value="<?= $value['id'] ?>" class="ids"/></td>
                            <td class="text-center">
                                <div style="width: 80px;">
                                    <img src="<?= $value['cover'] ?>" style="width: 30px;" />
                                </div>

                            </td>
                            <td>
                                <div style="min-width: 200px;">
                                    <a href="<?= Url::log($value['id']) ?>" target="_blank" class="">
                                        <?= $value['title'] ?>
                                    </a>
                                    <span class="text-muted">（ID:<?= $value['id'] ?>）</span>
                                </div>

                            </td>
                            <td class="text-center"><?= goodsTypeText($value['type']) ?></td>
                            <td class="text-center">
                                <a href="stock.php?action=add&goods_id=<?= $value['id'] ?>" class="text-primary">
                                    添加库存 (<?= $value['stock'] ?? 0 ?>)
                                </a>
                            </td>
                            <td class="text-center">
                                <a href="<?= Url::sort($value['sort_id']) ?>" target="_blank"><?= $sortName ?></a>
                            </td>
                            <td class="text-center">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="shelf-<?= $key ?>" name="is_on_shelf" value="<?= $value['is_on_shelf'] ?>" <?= $value['is_on_shelf'] == 1 ? 'checked' : '' ?>>
                                    <label class="custom-control-label is-on-shelf" data-goods_id="<?= $value['id'] ?>" for="shelf-<?= $key ?>"></label>
                                </div>
                            </td>
                            <td class="text-center">
                                <span><?= $value['sales'] ?></span>
                            </td>
                            <td class="text-center"><?= $value['create_time'] ?></td>
                            <td class="text-center">
                                <a href="goods.php?action=edit&id=<?= $value['id'] ?>" class="btn btn-sm btn-primary">
                                    <i class="fa fa-edit"></i> 编辑
                                </a>
                                <a href="javascript: eb_confirm(<?= $value['id'] ?>, 'goods', '<?= LoginAuth::genToken() ?>');" class="btn btn-sm btn-danger">
                                    <i class="fa fa-trash"></i> 删除
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>

        </form>

        <div class="page"><?= $pageurl ?> </div>
    </div>

</div>

<script>
    $(function () {
        $("#menu-goods").attr('class', 'has-list in');
        $("#menu-goods .icon-you").attr('class', 'fas arrow iconfont icon-you active');
        $("#menu-goods > .submenu").css('display', 'block');

        $('.is-on-shelf').click(function(){
            var goods_id = $(this).data('goods_id');
            $.post('?action=shelf', {goods_id: goods_id}, function (data) {
                layer.msg('操作成功');
            }).fail(function () {
                layer.msg('操作失败');
            });
        })


    });
</script>
