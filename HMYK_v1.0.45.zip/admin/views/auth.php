<?php defined('EM_ROOT') || exit('access denied!'); ?>
<?php if (isset($_GET['error_b'])): ?>
    <div class="alert alert-danger">注册失败了，可能是注册码不正确，或服务器无法访问官网 <?= SERVICE_HOST ?></div><?php endif ?>

<div class="card shadow mb-4 mt-3">
    <div class="card-body">
        <?php if (!Register::isRegLocal()) : ?>
            <form action="auth.php?action=auth" method="post" class="mt-2">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" id="emkey" name="emkey" placeholder="请输入授权码" minlength="32" maxlength="32" required>
                    <div class="input-group-append">
                        <button class="btn btn-success" type="submit" id="button-addon2">立即授权</button>
                    </div>
                </div>
                <div class="form-group mt-2">
                    <a href="<?= SERVICE_HOST ?>/index/register/index" target="_blank" class="text-danger">获取授权码&rarr; </a>
                </div>
            </form>
        <?php else: ?>
            <div class="text-center">
                <p class="lead text-success my-5">恭喜，成功完成正版授权</p>
            </div>
        <?php endif ?>
    </div>
</div>
