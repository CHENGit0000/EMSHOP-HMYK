<?php defined('EM_ROOT') || exit('access denied!'); ?>




<footer class="sticky-footer bg-white" style="padding: 10px 15px;">
    <div class="text-right my-auto mr-4">
        <small><a href="<?= SERVICE_HOST ?>" target="_blank"><?= SERVICE_NAME ?></a> - v<?= ucfirst(Option::EM_VERSION) ?></small>
    </div>
</footer>


</div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="icofont-rounded-up"></i>
</a>

</div>
</div>
<?php doAction('adm_footer') ?>

<script src="./views/js/sb-admin-2.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
<script>
    $(function () {
        $(document).on('click', 'a.scroll-to-top', function (e) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: ($($anchor.attr('href')).offset().top)
            }, 1000, 'easeInOutExpo');
            e.preventDefault();
        });



        // 初始化
        const menu = $("#left-menu");
        const overlay = $(".overlay");
        const toggleBtn = $(".show-nav");
        overlay.css({ opacity: 0, display: "none" });

        // 切换菜单
        toggleBtn.click(function() {
            if (menu.css("left") === "-220px") {
                // 打开菜单
                menu.css("display", "block").animate({ left: "0px" }, 400, "easeOutQuart");
                overlay.css("display", "block").animate({ opacity: 0.3 }, 300);
            } else {
                // 关闭菜单
                menu.animate({ left: "-220px" }, 300, "easeInQuart", function() {
                    menu.css("display", "none");
                });
                overlay.animate({ opacity: 0 }, 300, function() {
                    overlay.css("display", "none");
                });
            }
        });

        // 点击遮罩层关闭菜单
        overlay.click(function() {
            menu.animate({ left: "-200px" }, 300, "easeInQuart", function() {
                menu.css("display", "none");
            });
            overlay.animate({ opacity: 0 }, 300, function() {
                overlay.css("display", "none");
            });
        });

    });
</script>
</body>
</html>
