<?php defined('EM_ROOT') || exit('access denied!'); ?>
<?php if (isset($_GET['add_shortcut_suc'])): ?>
    <div class="alert alert-success">设置成功</div>
<?php endif ?>



<div class="row" style="margin-top: 10px; margin-bottom: 14px;">
    <div class="col-lg-12">
        <?php doAction('adm_main_top') ?>
    </div>
</div>



<?php if (User::isAdmin()): ?>
    <?php if (!Register::isRegLocal()) : ?>
        <div class="row" style="">
            <div class="col-lg-12">
                <div class="card" style="font-size: 13px;">
                    <div class="card-header" style="background: #ffe5e0; color: #ea644a; border: 1px solid #ffc6c7;">您安装的<?= SERVICE_NAME ?>尚未授权，完成授权可使用全部功能，包括如下：</div>
                    <ul class="list-group list-group-flush" style="border: 1px solid #ffc6c7; border-top: none;">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            1. 解锁在线升级功能，一键升级到最新版本，获得来自官方的安全和功能更新
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            2. 解锁应用商店，获得更多模板和插件，并支持应用在线一键更新
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            3. 去除所有未注册提示及功能限制，加入专属Q群，获得官方技术指导问题解答
                        </li>
                        <li class="list-group-item d-flex">
                            <a href="auth.php" class="btn btn-sm btn-primary shadow-lg mr-2">去授权</a>
                            <a href="<?= SERVICE_HOST ?>/index/register/index" target="_blank" class="btn btn-sm btn-success shadow-lg">获取授权码-></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    <?php endif ?>

    <style>
        @media (max-width: 576px) {
            #update-modal .modal-dialog {
                max-width: 95%;
                margin: 2vh auto;
            }
        }
    </style>
    <div class="modal fade" id="update-modal" tabindex="-1" role="dialog" aria-labelledby="update-modal-label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" style="max-width: 90%; max-height: 90vh; margin: 5vh auto;">
            <!-- 添加 modal-dialog-scrollable 和 max-height -->
            <div class="modal-content" style="height: auto; max-height: 90vh; display: flex; flex-direction: column;">
                <div class="modal-header">
                    <h5 class="modal-title" id="update-modal-label">检查更新</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="overflow-y: auto; flex: 1; min-height: 0;">
                    <!-- 添加 flex 布局和滚动 -->
                    <div id="update-modal-loading"></div>
                    <div id="update-modal-msg" class="text-center"></div>
                    <div id="update-modal-changes" style="max-height: calc(90vh - 200px); overflow-y: auto;"></div>
                    <!-- 为变化内容单独添加滚动 -->
                    <div id="update-modal-btn" class="mt-2 text-right"></div>
                </div>
            </div>
        </div>
    </div>


<?php endif ?>



<div class="row" style="">
    <?php if (User::isAdmin()): ?>
        <div class="col-lg-6 mb-3 mt-3">
            <div class="card">
                <div class="card-header">系统信息</div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        PHP
                        <span class="small pull-right"><?= $php_ver ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        数据库
                        <span class="small pull-right">MySQL <?= $mysql_ver ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Web服务
                        <span class="small pull-right"><?= $server_app ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        操作系统
                        <span class="small pull-right"><?= $os ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        系统时区
                        <span class="small pull-right"><?= Option::get('timezone') ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div class="pull-left">
                            <?php if (!Register::isRegLocal()) : ?>
                                <a href="<?= SERVICE_HOST ?>/index/register/index" target="_blank"><span class="badge badge-secondary"><?= SERVICE_NAME ?> - v<?= Option::EM_VERSION ?> 未授权</span></a>
                            <?php else: ?>
                                <a href="<?= SERVICE_HOST ?>" target="_blank"><span class="badge badge-success"><?= SERVICE_NAME ?> <?= ucfirst(Option::EM_VERSION) ?></span></a>
                                <?php if (Register::getRegType() === 2): ?>
                                    <a href="<?= SERVICE_HOST ?>/index/register/index" target="_blank" class="badge badge-warning">SVIP</a>
                                <?php elseif (Register::getRegType() === 1): ?>
                                    <a href="<?= SERVICE_HOST ?>/index/register/index" target="_blank" class="badge badge-success">VIP</a>
                                <?php else: ?>
                                    <a href="<?= SERVICE_HOST ?>/index/register/index" target="_blank" class="badge badge-success">已注册</a>
                                <?php endif ?>
                            <?php endif; ?>
                        </div>
                        <div class="pull-right">
                            <a id="ckup" href="javascript:checkUpdate();" class="badge badge-success d-flex align-items-center"><span>更新</span></a>
                        </div>
                    </li>
                </ul>
            </div>

        </div>

    <style>
        .badge{
            font-size: 90%;
        }
    </style>

        <script>
            setTimeout(hideActived, 3600);

            $("#menu-dashboard").addClass('active');

            // auto check update
            $.get("./upgrade.php?action=check_update", function (result) {
                if (result.code === 200) {
                    $("#ckup").append('&nbsp;&nbsp;&nbsp;&nbsp;<span class="badge bg-danger ml-1">发现新版本</span>');
                }
            });
        </script>

    <?php endif; ?>
    <!--<div class="col-lg-6 mb-3 mt-3">
        <div class="card">
            <div class="card-header">站点信息</div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="./article.php?checked=n">商品数量</a>
                    <a href="./article.php?checked=n"><span class="pull-right"><?php /*= $goods_count */?></span></a>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="./comment.php?hide=y">注册用户数</a>
                    <a href="./comment.php?hide=y"><span class="pull-right"><?php /*= $user_count */?></span></a>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center disabled">
                    <a href="./user.php">待处理订单</a>
                    <a href="./user.php"><span class="pull-right"><?php /*= $dcl_order */?></span></a>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="./article.php">今日订单</a>
                    <a href="./article.php"><span class="pull-right"><?php /*= $today_order */?></span></a>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="./twitter.php?all=y">昨日订单</a>
                    <a href="./twitter.php?all=y"><span class="pull-right"><?php /*= $yesterday_order */?></span></a>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="./comment.php">近七日订单</a>
                    <a href="./comment.php"><span class="pull-right"><?php /*= $sevenday_order */?></span></a>
                </li>
            </ul>
        </div>
    </div>-->

</div>


<?php if (User::isAdmin()): ?>
    <div class="row">
        <?php doAction('adm_main_content') ?>
    </div>
<?php endif; ?>