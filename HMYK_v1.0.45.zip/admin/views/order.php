<?php
defined('EM_ROOT') || exit('access denied!');
?>
<style>
    .quick-remarks {
        color: #666;
        font-size: 13px;
    }
    .quick-remark {
        color: #1890ff;
        cursor: pointer;
        margin: 0 3px;
    }
    .quick-remark:hover {
        text-decoration: underline;
        color: #40a9ff;
    }

</style>



<div class="card shadow mt-3">

    <div class="card-body">
        <form action="order.php" method="get">
            <div style="float: right;">
                <div class="input-group mb-4">

                    <input type="text" name="keyword" value="<?= $keyword ?>"
                           class="form-control"
                           placeholder="搜索订单"
                           aria-label="Search articles"
                           aria-describedby="search-icon">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">
                            搜索
                        </button>
                    </div>
                </div>
            </div>

        </form>


        <form action="goods.php?action=operate_product" method="post" name="form_log" id="form_log">
            <input type="hidden" name="draft" value="<?= $draft ?>">

            <div class="table-responsive">

                <table class="table table-bordered table-striped table-hover dataTable no-footer">
                    <thead>
                    <tr>
                        <th><input type="checkbox" id="checkAllItem"/></th>
                        <th>订单号</th>
                        <th style="min-width: 180px;">商品信息</th>
                        <th style="min-width: 90px;">下单数量</th>
                        <th style="min-width: 90px;">订单金额</th>
                        <th style="min-width: 100px;">用户信息</th>
                        <th style="min-width: 90px;" class="text-center">订单状态</th>
                        <th style="min-width: 90px;" class="text-center">支付方式</th>
                        <th style="min-width: 110px;" class="text-center">创建时间</th>
                        <th style="min-width: 110px;" class="text-center">支付时间</th>
                        <th>操作</th>
                    </tr>
                    </thead>
                    <tbody class="checkboxContainer">
                    <?php
                    foreach ($order as $key => $val):
                    ?>
                        <tr>
                            <td style="width: 20px;"><input type="checkbox" name="order[]" value="<?= $val['id'] ?>" class="ids"/></td>
                            <td>
                                <p><?= $val['out_trade_no'] ?></p>
                                <p><?= $val['up_no'] ?></p>
                            </td>
                            <td>
                                <?php foreach($val['list'] as $v): ?>
                                <div><?= $v['title'] ?><?= empty($v['attr_spec']) ? '' : " <br /><small> " . $v['attr_spec'] . '</small>'  ?></div>
                                <?php endforeach; ?>
                                <?php if(!empty($val['list'][0]['attach_user'])): ?>
                                <div><small><?= $val['list'][0]['attach_user'] ?></small></div>
                                <?php endif; ?>
                            </td>
                            <td><?= $val['list'][0]['quantity'] ?></td>
                            <td><?= $val['amount'] ?></td>
                            <td>
                                <?php if($val['user_id'] == 0): ?>
                                    <div style="">游客</div>
                                <?php else: ?>
                                <?php endif; ?>
                                <div style="text-align: "><?= $val['client_ip'] ?></div>
                            </td>
                            <td class="text-center"><?= $val['status'] ?></td>
                            <td class="text-center">
                                <?php if(!empty($val['pay_time'])): ?>
                                <?= $val['payment'] ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div style=" text-align: center;">
                                    <div><?= date('Y-m-d', $val['create_time']) ?></div>
                                    <div><?= date('H:i:s', $val['create_time']) ?></div>
                                </div>

                            </td>
                            <td>
                                <?php if(!empty($val['pay_time'])): ?>
                                <div style="text-align: center;">
                                    <div><?= date('Y-m-d', $val['pay_time']) ?></div>
                                    <div><?= date('H:i:s', $val['pay_time']) ?></div>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($val['list'][0]['type'] == 'xuni' && $val['status'] == '待发货'): ?>
                                    <a href="javascript:;" data-id="<?= $val['id'] ?>" class="badge badge-warning deliver-order-btn">发货</a>
                                <?php endif; ?>
                                <?php if(!$val['pay_time']): ?>
                                <a href="javascript: eb_confirm('<?= $val['out_trade_no'] ?>', 'repay', '<?= LoginAuth::genToken() ?>');" class="badge badge-primary">补单</a>
                                <?php endif; ?>
                                <a href="javascript:;" data-id="<?= $val['id'] ?>" class="badge badge-danger del-order-btn">删除</a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
            <input name="operate" id="operate" value="" type="hidden"/>
        </form>
        <div class="page"><?= $pageurl ?> </div>
    </div>
</div>

<script>


    $(function () {

        $("#menu-order").attr('class', 'has-list in');
        $("#menu-order .icon-you").attr('class', 'fas arrow iconfont icon-you active');
        $("#menu-order > .submenu").css('display', 'block');

        setTimeout(hideActived, 3600);


        function showDeliverDialog(id) {
            layer.open({
                type: 1,
                title: '发货信息填写',
                area: ['400px', '290px'],
                content: `
            <form id="deliver-form" method="post" style="padding: 15px;">
                <div style="margin-top: -5px; margin-bottom: 8px;">确认提交后，虚拟服务订单流程结束</div>
                <textarea id="remark-text" name="remark" class="form-control" rows="3" placeholder="请填写备注...">服务已完成</textarea>
                <div class="quick-remarks mt-3" style="margin-top: 5px;">
                    <span>快速填写：</span>
                    <a href="javascript:;" class="quick-remark" data-text="服务已完成">服务已完成</a> |
                    <a href="javascript:;" class="quick-remark" data-text="问题已解决">问题已解决</a>
                </div>
                <input type="hidden" name="deliver_time" value="<?= date('Y-m-d H:i:s') ?>">
            </form>
        `,
                btn: ['确认发货', '取消'],
                yes: function(index, layero) {
                    const remark = $('#remark-text').val().trim();
                    if (!remark) {
                        layer.msg('请填写发货备注信息！');
                        return false;
                    }
                    submitDeliverForm(id);
                    layer.close(index); // 关闭对话框
                },
                cancel: function(index, layero) {
                    // 点击取消按钮的回调，可省略
                },
                shadeClose: true // 点击遮罩关闭
            });

            // 快速填写点击事件
            $(document).on('click', '.quick-remark', function() {
                const text = $(this).data('text');
                $('#remark-text').val(text).focus();
            });
        }

        function submitDeliverForm(id) {
            // 创建临时form
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'order.php?action=deliver&id=' + id + '&token=<?= LoginAuth::genToken() ?>';
            form.style.display = 'none';

            // 添加remark字段
            const remarkInput = document.createElement('input');
            remarkInput.type = 'hidden';
            remarkInput.name = 'remark';
            remarkInput.value = $('#remark-text').val();
            form.appendChild(remarkInput);

            // 添加deliver_time字段
            const timeInput = document.createElement('input');
            timeInput.type = 'hidden';
            timeInput.name = 'deliver_time';
            timeInput.value = '<?= date('Y-m-d H:i:s') ?>';
            form.appendChild(timeInput);

            // 提交表单
            document.body.appendChild(form);
            form.submit();

        }

        // 调用示例
        // showDeliverDialog(订单ID);

        $('.del-order-btn').click(function(){
            var id = $(this).data('id');


            layer.confirm('确定要删除这个订单吗？', {icon: 3, title: '温馨提示', skin: 'class-layer-danger', btn: ['确定', '取消']}, function (index) {
                window.location = 'order.php?action=delete&id=' + id + '&token=<?= LoginAuth::genToken() ?>';
                layer.close(index);
            });

        })

        $('.deliver-order-btn').click(function(){
            var id = $(this).data('id');

            showDeliverDialog(id)
        })

    });
</script>
