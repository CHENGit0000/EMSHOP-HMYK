<?php defined('EM_ROOT') || exit('access denied!'); ?>
<?php if (isset($_GET['error'])): ?>
    <div class="alert alert-danger">商店暂不可用，可能是网络问题</div><?php endif ?>





<div class="row mb-4 ml-1 mt-3">
    <ul class="nav nav-pills">
        <li class="nav-item"><a class="nav-link" href="./store.php">全部应用</a></li>
        <li class="nav-item"><a class="nav-link active" href="./store.php?action=tpl">模板主题</a></li>
        <li class="nav-item"><a class="nav-link" href="./store.php?action=plu">扩展插件</a></li>
    </ul>
</div>



<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <div class="my-3" id="upMsg"></div>
            <?php if (!empty($templates)): ?>
                <table class="table table-striped table-hover dataTable no-footer">
                    <thead>
                    <tr>
                        <th>插件名</th>
                        <th class="text-center">市场价</th>
                        <th class="text-center">SVIP售价</th>
                        <th class="text-center">开发者</th>
                        <th class="text-center">插件版本</th>
                        <th class="text-center">程序版本</th>
                        <!--                    <th class="text-center">更新时间</th>-->
                        <th class="text-center">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    foreach ($templates as $k => $v):
                        $type = $v['type'] === 'template' ? 'tpl' : 'plugin';
                        $order_url = SERVICE_HOST . '/index/order/submit/' . $type . '/' . $v['id'];
                        ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <img src="<?= $v['img'] ?>" height="45" width="45" class="rounded"/>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <div class="align-items-center mb-3">
                                            <p class="mb-0 m-2">
                                                <?= $v['name'] ?>
                                                <?php if ($type === 'tpl'): ?>
                                                    <span class="badge badge-success p-1">模板</span>
                                                <?php else: ?>
                                                    <span class="badge badge-primary p-1">插件</span>
                                                <?php endif; ?>
                                            </p>
                                            <p class="mb-0 m-2 small"><?= $v['description'] ?> </p>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <td class="text-center">
                                <div class="mt-3">
                                    <?php if ($v['vip_price'] > 0): ?>
                                        <div style="color: #dc3545;">
                                            <?= $v['vip_price'] ?> <small>元</small>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-success">免费</div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="text-center">
                                <div class="mt-3">
                                    <?php if ($v['svip_price'] > 0): ?>
                                        <div style="color: #dc3545;">
                                            <?= $v['svip_price'] ?> <small>元</small>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-success">免费</div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="text-center">
                                <div class="mt-3">
                                    <?= $v['author'] ?>
                                </div>
                            </td>
                            <td class="text-center">
                                <div class="mt-3 "><?= $v['version'] ?></div>
                            </td>
                            <td class="text-center">
                                <div class="mt-3 ">v<?= $v['min_version'] ?>及以上</div>
                            </td>
                            <td class="text-center">
                                <div class="mt-3">
                                    <div class=" justify-content-center">
                                        <div class="installMsg mb-2" ></div>
                                        <div>
                                            <?php if(in_array($v['english_name'], $install_plugin)): ?>
                                                <button type="button" class="btn btn-secondary btn-sm" disabled>已安装</button>
                                            <?php else: ?>
                                                <?php if(Register::getRegType() == 1): ?>
                                                    <?php if($v['vip_price'] > 0): ?>
                                                        <?php if($v['pay'] == 'y'): ?>
                                                            <a href="#" class="btn btn-success installBtn btn-sm" data-url="<?= urlencode($v['download_url']) ?>" data-cdn-url="<?= urlencode($v['cdn_download_url']) ?>" data-type="<?= $type ?>">已购买，立即安装</a>
                                                        <?php else: ?>
                                                            <a href="<?= $order_url ?>" class="btn btn-danger btn-sm" target="_blank">立即购买</a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <a href="#" class="btn btn-success installBtn btn-sm" data-url="<?= urlencode($v['download_url']) ?>" data-cdn-url="<?= urlencode($v['cdn_download_url']) ?>" data-type="<?= $type ?>">免费安装</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if(Register::getRegType() == 2): ?>
                                                    <?php if($v['svip_price'] > 0): ?>
                                                        <?php if($v['pay'] == 'y'): ?>
                                                            <a href="#" class="btn btn-success installBtn btn-sm" data-url="<?= urlencode($v['download_url']) ?>" data-cdn-url="<?= urlencode($v['cdn_download_url']) ?>" data-type="<?= $type ?>">已购买，立即安装</a>
                                                        <?php else: ?>
                                                            <a href="<?= $order_url ?>" class="btn btn-danger btn-sm" target="_blank">立即购买</a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <a href="#" class="btn btn-success installBtn btn-sm" data-url="<?= urlencode($v['download_url']) ?>" data-cdn-url="<?= urlencode($v['cdn_download_url']) ?>" data-type="<?= $type ?>">免费安装</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <?php if(Register::getRegType() == 0): ?>
                                                    <button type="button" class="btn btn-danger btn-sm" disabled>限正版授权用户安装</button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
            未找到模板
            <?php endif; ?>
            <div class="page"><?= $pageurl ?> </div>
        </div>
    </div>
</div>
<script>
    $(function () {
        $("#menu_store").addClass('active');
        setTimeout(hideActived, 3600);

        $('#template-category').on('change', function () {
            var selectedCategory = $(this).val();
            if (selectedCategory) {
                window.location.href = './store.php?action=tpl&sid=' + selectedCategory;
            }
        });
    });
</script>
