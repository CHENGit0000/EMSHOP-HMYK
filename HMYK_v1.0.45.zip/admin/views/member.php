<?php defined('EM_ROOT') || exit('access denied!'); ?>

<style>
    /* 自定义表格样式 */
    .table-container {
        margin: 20px auto;
        max-width: 1200px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 1px solid #f0f0f0;
    }

    .table-header h3 {
        margin: 0;
        color: #333;
        font-weight: 600;
    }

    .search-box {
        position: relative;
        width: 240px;
    }

    .search-box input {
        padding-left: 35px;
        border-radius: 20px;
        border: 1px solid #ddd;
        transition: all 0.3s ease;
    }

    .search-box input:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .search-box .fa-search {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #999;
    }

    .table-responsive {
        padding: 20px;
    }

    /* 表格样式优化 */
    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table thead th {
        background-color: #f8f9fa;
        color: #555;
        font-weight: 600;
        border-bottom: 2px solid #e9ecef;
        padding: 12px 15px;
        text-align: left;
    }

    .custom-table tbody td {
        padding: 12px 15px;
        border-bottom: 1px solid #f2f2f2;
        transition: background-color 0.2s ease;
    }

    .custom-table tbody tr:hover {
        background-color: #f9f9f9;
    }

    /* 按钮样式 */
    .btn-action {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 14px;
        transition: all 0.2s ease;
    }

    .btn-edit {
        background-color: #4CAF50;
        color: white;
        margin-right: 5px;
    }

    .btn-edit:hover {
        background-color: #45a049;
        color: white;
    }

    .btn-delete {
        background-color: #f44336;
        color: white;
    }

    .btn-delete:hover {
        background-color: #da190b;
        color: white;
    }

    /* 新增按钮样式 */
    .btn-add {
        background-color: #007bff;
        color: white;
        margin-right: 10px;
    }

    .btn-add:hover {
        background-color: #0069d9;
        color: white;
    }

    /* 批量删除按钮样式 */
    .btn-batch-delete {
        background-color: #dc3545;
        color: white;
    }

    .btn-batch-delete:hover {
        background-color: #c82333;
        color: white;
    }

    .btn-batch-delete:disabled {
        background-color: #e2e3e5;
        color: #737373;
        cursor: not-allowed;
    }

    /* 分页样式 */
    .pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        border-top: 1px solid #f0f0f0;
    }

    .pagination {
        margin: 0;
    }

    .pagination li a {
        color: #007bff;
        border: 1px solid #ddd;
        padding: 6px 12px;
        margin-left: -1px;
        transition: all 0.2s ease;
    }

    .pagination li a:hover {
        background-color: #f2f2f2;
    }

    .pagination li.active a {
        background-color: #007bff;
        color: white;
        border-color: #007bff;
    }

    /* 模态框样式 */
    .modal-content {
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .modal-title {
        font-weight: 600;
        color: #333;
    }

    .modal-footer {
        border-top: 1px solid #e9ecef;
    }

    /* 响应式调整 */
    @media (max-width: 768px) {
        .table-header {
            flex-direction: column;
            align-items: flex-start;
        }

        .search-box {
            margin-top: 15px;
            width: 100%;
        }

        .pagination-container {
            flex-direction: column;
        }

        .pagination-info {
            margin-bottom: 15px;
        }
    }



    /* 自定义模态框宽度 */
    .modal-dialog-custom {
        max-width: 90%;
        width: auto;
    }

    /* 小屏幕设备优化 */
    @media (max-width: 768px) {
        .modal-dialog-custom {
            max-width: 95%;
        }
    }

    /* 确保按钮在最上层 */
    .modal-footer .btn {
        position: relative;
        z-index: 1050; /* 确保按钮在模态框的z-index之上 */
    }

    /* 修改模态框动画为淡入淡出 */
    .modal.fade .modal-dialog {
        transition: transform 0.2s ease-out, opacity 0.2s ease-out;
        transform: translate(0, 0) scale(0.95);
        opacity: 0;
    }

    .modal.show .modal-dialog {
        transform: translate(0, 0) scale(1);
        opacity: 1;
    }

    /* 背景遮罩淡入淡出 */
    .modal-backdrop.fade {
        opacity: 0;
    }

    .modal-backdrop.show {
        opacity: 0.1;
    }

</style>


<div class="">
    <div class="table-container">
        <!-- 表格头部 -->
        <div class="table-header">
            <div class="btn-group">
                <button class="btn btn-action btn-add" data-toggle="modal" data-target="#addModal">
                    <i class="fa fa-plus"></i> 新增
                </button>
                <button class="btn btn-action btn-batch-delete" id="batchDeleteBtn" disabled>
                    <i class="fa fa-trash"></i> 删除选中
                </button>
            </div>
            <div class="search-box">
                <i class="fa fa-search"></i>
                <input type="text" class="form-control" placeholder="搜索等级名称...">
            </div>
        </div>

        <!-- 表格内容 -->
        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th style="width: 50px;"><input type="checkbox" id="selectAll"></th>
                        <th style="width: 80px;">ID</th>
                        <th>等级名称</th>
                        <th style="width: 180px;">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($members as $val): ?>
                        <tr>
                            <td><input type="checkbox" class="select-item"></td>
                            <td><?= $val['id'] ?></td>
                            <td><?= $val['name'] ?></td>
                            <td>
                                <button class="btn btn-action btn-edit" data-toggle="modal" data-target="#editModal">
                                    <i class="fa fa-pencil"></i> 编辑
                                </button>
                                <button class="btn btn-action btn-delete" data-toggle="modal" data-target="#deleteModal">
                                    <i class="fa fa-trash"></i> 删除
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- 分页 -->
        <?php if($dataCount > Option::get('admin_article_perpage_num')): ?>
        <div class="pagination-container">
            <div class="page"><?= $pageurl ?></div>
        </div>
        <?php endif ?>
    </div>
</div>

<!-- 新增模态框 -->
<div class="modal fade modal-center" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalLabel">新增等级</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form-group">
                        <label for="addLevelName">等级名称</label>
                        <input type="text" class="form-control" id="addLevelName" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <input name="token" id="add-token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary">保存</button>
            </div>
        </div>
    </div>
</div>

<!-- 编辑模态框 -->
<div class="modal fade modal-center" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">编辑等级</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form-group">
                        <label for="editId">ID</label>
                        <input type="text" class="form-control" id="editId" readonly>
                    </div>
                    <div class="form-group">
                        <label for="editLevelName">等级名称</label>
                        <input type="text" class="form-control" id="editLevelName" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <input name="token" id="edit-token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary">保存更改</button>
            </div>
        </div>
    </div>
</div>

<!-- 删除确认模态框 -->
<div class="modal fade modal-center" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">确认删除</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>确定要删除此等级吗？此操作不可撤销。</p>
                <input type="hidden" id="deleteId">
            </div>
            <div class="modal-footer">
                <input name="token" id="delete_token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-danger">删除</button>
            </div>
        </div>
    </div>
</div>
<!-- 批量删除确认模态框 -->
<div class="modal fade modal-center" id="batchDeleteModal" tabindex="-1" role="dialog" aria-labelledby="batchDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="batchDeleteModalLabel">确认批量删除</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>确定要删除选中的等级吗？此操作不可撤销。</p>
                <input type="hidden" id="batchDeleteIds">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-danger" id="confirmBatchDelete">删除</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {


        $('#addModal .btn-primary').on('click', function() {
            // 获取等级名称
            var name = $('#addLevelName').val().trim();
            var add_token = $('#add-token').val().trim();

            $.post('?action=add', {name: name, token: add_token}, function(e){
                // 关闭模态框
                $('#addModal').modal('hide');
                location.reload();
            },"json");
        });


        $('#deleteModal .btn-danger').on('click', function() {
            // 获取等级名称
            var id = $('#deleteId').val().trim();
            var token = $('#delete_token').val().trim();

            $.post('?action=del', {id: id, token: token}, function(e){
                // 关闭模态框
                $('#deleteModal').modal('hide');
                location.reload();
            },"json");
        });

        $('#editModal .btn-primary').on('click', function() {
            // 获取等级名称
            var id = $('#editId').val();
            var name = $('#editLevelName').val().trim();
            var token = $('#edit-token').val().trim();

            $.post('?action=edit', {name: name, token: token, id: id}, function(e){
                // 关闭模态框
                $('#editModal').modal('hide');
                location.reload();
            },"json");
        });



        // 编辑按钮点击事件
        $('.btn-edit').on('click', function() {
            var row = $(this).closest('tr');
            var id = row.find('td:eq(1)').text(); // 注意索引变化，因为增加了复选框列
            var levelName = row.find('td:eq(2)').text();

            $('#editId').val(id);
            $('#editLevelName').val(levelName);
        });

        // 删除按钮点击事件
        $('.btn-delete').on('click', function() {
            var row = $(this).closest('tr');
            var id = row.find('td:eq(1)').text(); // 注意索引变化，因为增加了复选框列

            $('#deleteId').val(id);
        });

        // 全选/取消全选
        $('#selectAll').on('change', function() {
            var isChecked = $(this).prop('checked');
            $('.select-item').prop('checked', isChecked);
            updateBatchDeleteButton();
        });

        // 单个选择框变化时
        $('.select-item').on('change', function() {
            // 如果所有单选框都被选中，则全选框也被选中
            var allChecked = $('.select-item:checked').length === $('.select-item').length;
            $('#selectAll').prop('checked', allChecked);

            // 如果有任何单选框被选中，则部分选中
            var anyChecked = $('.select-item:checked').length > 0;
            if (anyChecked && !allChecked) {
                $('#selectAll').prop('indeterminate', true);
            } else {
                $('#selectAll').prop('indeterminate', false);
            }

            updateBatchDeleteButton();
        });

        // 更新批量删除按钮状态
        function updateBatchDeleteButton() {
            var selectedCount = $('.select-item:checked').length;
            $('#batchDeleteBtn').prop('disabled', selectedCount === 0);
        }

        // 批量删除按钮点击事件
        $('#batchDeleteBtn').on('click', function() {
            var selectedIds = [];
            $('.select-item:checked').each(function() {
                var row = $(this).closest('tr');
                var id = row.find('td:eq(1)').text(); // 注意索引变化，因为增加了复选框列
                selectedIds.push(id);
            });

            $('#batchDeleteIds').val(selectedIds.join(','));
            $('#batchDeleteModal').modal('show');
        });

        // 确认批量删除
        $('#confirmBatchDelete').on('click', function() {
            // 这里可以添加实际的批量删除逻辑
            var selectedIds = $('#batchDeleteIds').val().split(',');
            console.log('批量删除ID:', selectedIds);

            // 演示用：删除选中的行
            $('.select-item:checked').each(function() {
                $(this).closest('tr').remove();
            });

            // 重置选择状态
            $('#selectAll').prop('checked', false);
            $('#selectAll').prop('indeterminate', false);
            updateBatchDeleteButton();

            $('#batchDeleteModal').modal('hide');
        });

        // 搜索功能
        $('.search-box input').on('input', function() {
            var searchTerm = $(this).val().toLowerCase();

            $('.custom-table tbody tr').each(function() {
                var levelName = $(this).find('td:eq(2)').text().toLowerCase(); // 注意索引变化，因为增加了复选框列

                if (levelName.includes(searchTerm)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });

        // 分页功能
        $('.pagination li').on('click', function() {
            if (!$(this).hasClass('disabled') && !$(this).hasClass('active')) {
                $('.pagination li').removeClass('active');
                $(this).addClass('active');

                // 这里可以添加加载不同页面数据的逻辑
                // 为了演示，我们只是模拟分页效果
                var pageNumber = $(this).find('a').text();
                updatePaginationInfo(pageNumber);
            }
        });

        // 更新分页信息
        function updatePaginationInfo(pageNumber) {
            var itemsPerPage = 5;
            var startItem = (pageNumber - 1) * itemsPerPage + 1;
            var endItem = Math.min(pageNumber * itemsPerPage, 20);

            $('.pagination-info').text(`显示 ${startItem}-${endItem} 条，共 20 条`);
        }
    });
</script>
<script>
    $(function () {
        setTimeout(hideActived, 3600);
        $("#menu-user").attr('class', 'has-list in');
        $("#menu-user .icon-you").attr('class', 'fas arrow iconfont icon-you active');
        $("#menu-user > .submenu").css('display', 'block');

    });
</script>
