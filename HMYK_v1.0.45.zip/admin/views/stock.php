<?php
defined('EM_ROOT') || exit('access denied!');
?>

<style>
    /* 自定义表格样式 */
    .table-container {
        margin: 20px auto;
        max-width: 1200px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 1px solid #f0f0f0;
    }

    .table-header h3 {
        margin: 0;
        color: #333;
        font-weight: 600;
    }

    .search-box {
        position: relative;
        width: 240px;
    }

    .search-box input {
        padding-left: 35px;
        border-radius: 20px;
        border: 1px solid #ddd;
        transition: all 0.3s ease;
    }

    .search-box input:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .search-box .fa-search {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #999;
    }

    .table-responsive {
        padding: 20px;
    }

    /* 表格样式优化 */
    .custom-table {
        width: 100%;
        border-collapse: collapse;
    }

    .custom-table thead th {
        background-color: #f8f9fa;
        color: #555;
        font-weight: 600;
        border-bottom: 2px solid #e9ecef;
        padding: 12px 15px;
        text-align: left;
    }

    .custom-table tbody td {
        padding: 12px 15px;
        border-bottom: 1px solid #f2f2f2;
        transition: background-color 0.2s ease;
    }

    .custom-table tbody tr:hover {
        background-color: #f9f9f9;
    }

    /* 按钮样式 */
    .btn-action {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 14px;
        transition: all 0.2s ease;
    }

    .btn-edit {
        background-color: #4CAF50;
        color: white;
        margin-right: 5px;
    }

    .btn-edit:hover {
        background-color: #45a049;
        color: white;
    }

    .btn-delete {
        background-color: #f44336;
        color: white;
    }

    .btn-delete:hover {
        background-color: #da190b;
        color: white;
    }

    /* 新增按钮样式 */
    .btn-add {
        background-color: #007bff;
        color: white;
        margin-right: 10px;
    }

    .btn-add:hover {
        background-color: #0069d9;
        color: white;
    }

    /* 批量删除按钮样式 */
    .btn-batch-delete {
        background-color: #dc3545;
        color: white;
    }

    .btn-batch-delete:hover {
        background-color: #c82333;
        color: white;
    }

    .btn-batch-delete:disabled {
        background-color: #e2e3e5;
        color: #737373;
        cursor: not-allowed;
    }

    /* 分页样式 */
    .pagination-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        border-top: 1px solid #f0f0f0;
    }

    .pagination {
        margin: 0;
    }

    .pagination li a {
        color: #007bff;
        border: 1px solid #ddd;
        padding: 6px 12px;
        margin-left: -1px;
        transition: all 0.2s ease;
    }

    .pagination li a:hover {
        background-color: #f2f2f2;
    }

    .pagination li.active a {
        background-color: #007bff;
        color: white;
        border-color: #007bff;
    }

    /* 模态框样式 */
    .modal-content {
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .modal-title {
        font-weight: 600;
        color: #333;
    }

    .modal-footer {
        border-top: 1px solid #e9ecef;
    }

    /* 响应式调整 */
    @media (max-width: 768px) {
        .table-header {
            flex-direction: column;
            align-items: flex-start;
        }

        .search-box {
            margin-top: 15px;
            width: 100%;
        }

        .pagination-container {
            flex-direction: column;
        }

        .pagination-info {
            margin-bottom: 15px;
        }
    }



    /* 自定义模态框宽度 */
    .modal-dialog-custom {
        max-width: 90%;
        width: auto;
    }

    /* 小屏幕设备优化 */
    @media (max-width: 768px) {
        .modal-dialog-custom {
            max-width: 95%;
        }
    }

    /* 确保按钮在最上层 */
    .modal-footer .btn {
        position: relative;
        z-index: 1050; /* 确保按钮在模态框的z-index之上 */
    }

    /* 修改模态框动画为淡入淡出 */
    .modal.fade .modal-dialog {
        transition: transform 0.2s ease-out, opacity 0.2s ease-out;
        transform: translate(0, 0) scale(0.95);
        opacity: 0;
    }

    .modal.show .modal-dialog {
        transform: translate(0, 0) scale(1);
        opacity: 1;
    }

    /* 背景遮罩淡入淡出 */
    .modal-backdrop.fade {
        opacity: 0;
    }

    .modal-backdrop.show {
        opacity: 0.1;
    }
</style>

<style>
    .stock-content{
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        word-wrap: break-word;
    }
</style>


<div>
    <div class="table-container">
        <form action="goods.php?action=operate_goods" method="post" name="form_log" id="form_log">
            <input type="hidden" name="draft" value="<?= $draft ?>">
            <div>
                <table class="table table-striped table-hover scrollable-table">
                    <thead>
                    <tr>
                        <th><input type="checkbox" id="checkAllItem"/></th>
                        <th>商品名称</th>
                        <th>库存类型</th>
                        <th style="min-width: 200px; max-width: 300px;">库存内容</th>
                        <th style="width: 120px;">操作</th>
                    </tr>
                    </thead>
                    <tbody class="checkboxContainer">
                    <?php foreach ($list as $key => $value): ?>
                        <tr>
                            <td style="width: 20px;"><input type="checkbox" name="uniqid[]" value="<?= $value['uniqid'] ?>" class="ids"/></td>
                            <td>
                                <?= $value['title'] ?>
                                <?= $value['delete_time'] ? '<br><span style="color: #ea644a;">商品已删除</span>' : '' ?>
                            </td>
                            <td>
                                <?= goodsTypeText($value['type']) ?>
                                <i class="fa fa-remove"></i>
                                <?= $value['quantity'] ?>
                            </td>
							<td>
                                <div class="stock-content"><?= $value['content'] ?></div>

                            </td>
                            <td>
                                <a data-stock_id="<?= $value['stock_id'] ?>" data-token="<?= LoginAuth::genToken() ?>" class="btn btn-sm btn-danger del-stock-btn">
                                    <i class="fa fa-trash"></i> 删除
                                </a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
        </form>
        <div class="page"><?= $pageurl ?> </div>
    </div>
</div>

<script>
    $(function () {
        $("#menu-goods").attr('class', 'has-list in');
        $("#menu-goods .icon-you").attr('class', 'fas arrow iconfont icon-you active');
        $("#menu-goods > .submenu").css('display', 'block');
        setTimeout(hideActived, 3600);

        $('.del-stock-btn').click(function(){
            let stock_id = $(this).data('stock_id');
            let token = $(this).data('token');
            layer.confirm('确定删除这个库存吗？', {icon: 3, title: '温馨提示', skin: 'class-layer-danger', btn: ['删除', '取消']}, function (index) {
                window.location = '?action=del&stock_id=' + stock_id + '&token=' + token;
                layer.close(index);
            });
        })



    });
</script>
