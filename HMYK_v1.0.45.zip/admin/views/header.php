<?php defined('EM_ROOT') || exit('access denied!'); ?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name=renderer content=webkit>
    <title>管理中心 - <?= Option::get('blogname') ?></title>
    <link rel="shortcut icon" href="./views/images/favicon.ico"/>

    <!-- bootstrap v4.6.0 -->
    <link rel="stylesheet" href="./views/css/bootstrap.min.css">
    <!-- jquery v3.5.1 -->
    <script src="./views/js/jquery.min.3.5.1.js"></script>

    <!-- 字体 -->
    <link rel="stylesheet" type="text/css" href="./views/font-awesome-4.7.0/css/font-awesome.min.css">
    <!-- 上传 -->
    <link rel="stylesheet" type="text/css" href="./views/css/dropzone.css?t=<?= Option::EM_VERSION_TIMESTAMP ?>">
    <!-- 裁剪 -->
    <link rel="stylesheet" type="text/css" href="./views/css/cropper.min.css?t=<?= Option::EM_VERSION_TIMESTAMP ?>">
    <script src="./views/js/cropper.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>







    <link rel="stylesheet" type="text/css" href="./views/css/css-main.css?t=<?= Option::EM_VERSION_TIMESTAMP ?>">

    <script src="./views/js/bootstrap.bundle.min.4.6.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/js/jquery-ui.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/js/jquery.ui.touch-punch.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/js/jquery.ui.timepicker-addon.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/js/jquery.pjax.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/js/js.cookie-2.2.1.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>

    <script src="./views/js/common.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/components/layer/layer.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="./views/components/message.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <?php doAction('adm_head') ?>

    <link rel="stylesheet" href="./views/css/style.css">



    <style>
        .table-container{
            overflow: auto;
        }
        ul{
            padding: 0;
        }

        /* 编辑器样式 */
        .tox .tox-edit-area::before{
            border: none!important;
        }
        .tox .tox-promotion{
            display: none;
        }
    </style>

    <script>
        $(function(){
            var Accordion = function(el, multiple) {
                this.el = el || {};
                this.multiple = multiple || false;

                // Variables privadas
                var links = this.el.find('.link');
                // Evento
                links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
            }

            Accordion.prototype.dropdown = function(e) {
                var $el = e.data.el;
                $this = $(this),
                    $next = $this.next();

                $this.find('.arrow').toggleClass('active')

                $next.slideToggle();
                $this.parent().toggleClass('open');

                if (!e.data.multiple) {
                    $el.find('.submenu').not($next).slideUp().parent().removeClass('open');
                    $el.find('.submenu').not($next).slideUp().parent().children().children().removeClass('active');
                };
            }

            var accordion = new Accordion($('#accordion'), false);
        })
    </script>
</head>
<body id="page-top">
<div id="editor-md-dialog"></div>
<div id="box">

    <style>

        #box{
            max-width: 1600px;
            height: 98vh;
            margin: 0 auto;
        }
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #000;
            opacity: 0;
            z-index: 1000;
            display: none;
        }

        .show-nav img{
            width: 20px;
            cursor: pointer;
        }

        .mb-br{
            display: none;
        }
        /* 仅在屏幕宽度 < 768px 时生效 */
        @media (max-width: 767px) {
            #left-menu{
                position: fixed;
                z-index: 1000;
                left: -220px;
                top: 4px;
            }


            .pc-br{
                display: none;
            }
            .pc-nav{
                margin-top: 12px;
            }
            .mb-br{
                display: block;
            }

        }

    </style>

    <!-- 遮罩层 -->
    <div class="overlay"></div>




    <nav class="menu-container" style="box-shadow: 2px 0px 6px rgba(0, 0, 0, 0.1);" id="left-menu">
        <a href="/" target="_blank" style="color: #333; text-decoration: none; display: block; text-align: center; font-size: 18px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); padding: 11.5px;">
            <?= Option::get('blogname') ?>
        </a>
        <ul id="accordion" class="menu accordion" style="margin-top: 12px;  ">
            <li class="menu-item" id="menu-dashboard">
                <a href="./" class="menu-link"><i class="fa fa-one fa-dashboard"></i>控制台</a>
            </li>

            <li class="menu-item has-submenu" id="menu-goods">
                <div class="menu-link link">
                    <i class="fa fa-one fa-sitemap"></i>商品管理<i class="arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-goods-list" class="menu-item"><a href="goods.php" class="menu-link">商品列表</a></li>
                    <li id="menu-stock-list" class="menu-item"><a href="stock.php" class="menu-link">库存管理</a></li>
                    <li id="menu-sort-list" class="menu-item"><a href="sort.php" class="menu-link">商品分类</a></li>
                    <li id="menu-sku-list" class="menu-item"><a href="sku.php" class="menu-link">规格属性</a></li>
                </ul>
            </li>
            <li class="menu-item has-submenu" id="menu-order">
                <div class="menu-link link">
                    <i class="fa fa-one fa-list-ul"></i>订单管理<i class="arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-order-goods" class="menu-item"><a href="order.php" class="menu-link">商品订单</a></li>
                </ul>
            </li>

            <li class="menu-item has-submenu" id="menu-user">
                <div class="menu-link link">
                    <i class="fa fa-one fa-user"></i>用户管理<i class="arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-user-default" class="menu-item"><a href="user.php" class="menu-link">用户管理</a></li>
                    <li id="menu-user-member" class="menu-item"><a href="member.php" class="menu-link">会员等级</a></li>
                </ul>
            </li>
            <li class="menu-item has-submenu" id="menu-appearance">
                <div class="menu-link link">
                    <i class="fa fa-one fa-inbox"></i>外观设置<i class="arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-template" class="menu-item"><a href="template.php" class="menu-link">模板管理</a></li>
                    <li id="menu-navi" class="menu-item"><a href="navbar.php" class="menu-link">导航管理</a></li>
                    <li id="menu-page" class="menu-item"><a href="page.php" class="menu-link">页面管理</a></li>
                </ul>
            </li>

            <li id="menu-plugin" class="menu-item">
                <a href="plugin.php" class="menu-link"><i class="fa fa-one fa-sliders"></i>插件管理</a>
            </li>
            <li  class="menu-item has-submenu" id="menu-system">
                <div class="menu-link link">
                    <i class="fa fa-one fa-cog"></i>系统管理<i class="arrow fa fa-angle-right"></i>
                </div>
                <ul class="submenu">
                    <li id="menu-setting" class="menu-item"><a href="setting.php" class="menu-link">基础设置</a></li>
                    <li id="menu-media" class="menu-item"><a href="media.php" class="menu-link">资源管理</a></li>
                </ul>
            </li>
            <li id="menu-store" class="menu-item">
                <a href="store.php" class="menu-link">
                    <i class="fa fa-one fa-shopping-cart"></i>应用商店
                </a>
            </li>

            <?php doAction('adm_menu') ?>
        </ul>
        <?php if (!Register::isRegLocal()) : ?>

            <div class="card" style="width: 195px; margin: 20px auto 0 auto; ">
                <div class="card-header" style="background: #ffe5e0; color: #ea644a; border: 1px solid #ffc6c7;">温馨提示</div>
                <div class="card-body" style="padding: 15px 15px; border: 1px solid #ffc6c7; border-top: none;">
                    <p class="card-text" style="font-size: 13px; margin-bottom: 10px;">您安装的<?= SERVICE_NAME ?>尚未授权，完成授权解锁全部功能和服务</p>
                    <a class="btn btn-danger btn-sm" href="auth.php">去授权</a>
                </div>
            </div>

        <?php endif ?>
    </nav>



<style>
    .navbar-brand{
        padding: 0;
    }
    .breadcrumb{
        padding: 0;
        margin: 0;
        background: #fff;
    }
</style>


    <div id="" class="d-flex flex-column">
        <div id="content">
            <div class="container-fluid">

               <nav class="navbar navbar-light pc-nav" style="background: #fff;
                    border-top-left-radius: 12px;
                    border-top-right-radius: 12px;
                   box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
">
                   <nav aria-label="breadcrumb" style="float: left;">
                       <div class="pc-br">
                           <?= $br ?>
                       </div>
                       <div class="mb-br">
                           <div class="show-nav"><img src="./views/images/menu.png" /></div>
                       </div>
                   </nav>
                   <div style="float: right;">
                       <a class="navbar-brand" href="#" style="float: left;">
                           <img src="<?= $user['avatar'] ?>" width="30" height="30" alt="">
                       </a>

                       <div class="dropdown" style="float: left; line-height: 37px;">
                           <span class="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                               <?= $user['nickname'] ?>
                           </span>
                           <div class="dropdown-menu" style="left: -90px;">
                               <a class="dropdown-item" href="blogger.php">个人信息</a>
                               <a class="dropdown-item" href="account.php?action=logout">退出登录</a>
                           </div>
                       </div>
                   </div>
                </nav>
