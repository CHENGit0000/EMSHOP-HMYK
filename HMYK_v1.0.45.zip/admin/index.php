<?php
/**
 * control panel
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

if (empty($action)) {
    $avatar = empty($user_cache[UID]['avatar']) ? './views/images/avatar.svg' : '../' . $user_cache[UID]['avatar'];
    $name = $user_cache[UID]['name'];
    $br = '<ol class="breadcrumb">
                           <li class="breadcrumb-item active" aria-current="page">控制台</li>
                       </ol>';

    // server info
    $server_app = $_SERVER['SERVER_SOFTWARE'];
    $DB = Database::getInstance();
    $mysql_ver = $DB->getMysqlVersion();
    $max_execution_time = ini_get('max_execution_time') ?: '';
    $max_upload_size = ini_get('upload_max_filesize') ?: '';
    $php_ver = PHP_VERSION . ', ' . $max_execution_time . 's,' . $max_upload_size;
    $os = php_uname('s') . ' ' . php_uname('m');

    if (extension_loaded('curl')) {
        $c = curl_version();
        $php_ver .= ',curl';
    }
    if (class_exists('ZipArchive', false)) {
        $php_ver .= ',zip';
    }
    if (extension_loaded('gd')) {
        $php_ver .= ',gd';
    }

    $goodsModel = new Goods_Model();
    $userModel = new User_Model();
    $orderModel = new Order_Model();

    $goods_count = $goodsModel->getCount(); // 商品数量
    $user_count = $userModel->getCount(); // 注册用户数量
    $dcl_order = $orderModel->getDcl(); // 待处理订单
    $today_order = $orderModel->getTodayOrder(); // 今日订单
    $yesterday_order = $orderModel->getYesterdayOrder(); // 昨日订单
    $sevenday_order = $orderModel->getSevendayOrder(); // 近七日订单



    include View::getAdmView('header');
    require_once(View::getAdmView('index'));
    include View::getAdmView('footer');
    View::output();





}

if ($action === 'add_shortcut') {
    $shortcut = Input::postStrArray('shortcut');
    $shortcutSet = [];
    foreach ($shortcut as $item) {
        $item = explode('||', $item);
        $shortcutSet[] = [
            'name' => $item[0],
            'url'  => $item[1]
        ];
    }
    Option::updateOption('shortcut', json_encode($shortcutSet, JSON_UNESCAPED_UNICODE));
    $CACHE->updateCache('options');
    emDirect("./index.php?add_shortcut_suc=1");
}
