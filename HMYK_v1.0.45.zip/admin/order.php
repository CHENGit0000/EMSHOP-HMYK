<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

$orderModel = new Order_Model();
$Sort_Model = new Sort_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

// 订单列表
if (empty($action)) {
    $page = Input::getIntVar('page', 1);
    $orderNum = $orderModel->getOrderNum();

    $keyword = Input::getStrVar('keyword', false);

    $order = $orderModel->getOrderForAdmin($page, [
        'keyword' => $keyword
    ]);

//    d($order);die;

    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($orderNum, Option::get('admin_article_perpage_num'), $page, "order.php?{$subPage}&page=");


    $br = '<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">控制台</a></li>
        <li class="breadcrumb-item"><a href="./order.php">订单管理</a></li>
        <li class="breadcrumb-item active" aria-current="page">商品订单</li>
    </ol>';

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once View::getAdmView(User::haveEditPermission() ? 'order' : 'uc_order');
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

// 补单
if($action == 'repay'){
	
	LoginAuth::checkToken();
    $out_trade_no = Input::getStrVar('out_trade_no');
    $payController = new Pay_Controller();
    $payController->repay($out_trade_no);
}

// 删除订单
if ($action == 'delete') {
    $id = Input::getIntVar('id');
    LoginAuth::checkToken();

    $orderModel->delete($id);

    emDirect("./order.php?&active_del=1");
}

// 手动发货
if ($action == 'deliver') {
    $id = Input::getIntVar('id');
    LoginAuth::checkToken();
    $remark = Input::postStrVar('remark');
    $orderModel->handDeliver($id, $remark);
    emDirect("./order.php");
}
