<?php
/**
 * global
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once '../init.php';

$sta_cache = $CACHE->readCache('sta');
$user_cache = $CACHE->readCache('user');
$action = Input::getStrVar('action');

if(isset($user_cache[UID]['role'])){
	$role = $user_cache[UID]['role'];
	$role_name = User::getRoleName($role, UID);
}


loginAuth::checkLogin(NULL, 'user');


User::checkRolePermission();
