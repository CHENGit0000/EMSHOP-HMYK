<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

$goodsModel = new Goods_Model();
$Sort_Model = new Sort_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

if (empty($action)) {
    $draft = isset($_GET['draft']) ? (int)$_GET['draft'] : 0;
    $sid = isset($_GET['sid']) ? (int)$_GET['sid'] : '';
    $uid = isset($_GET['uid']) ? (int)$_GET['uid'] : '';
    $keyword = isset($_GET['keyword']) ? addslashes(trim($_GET['keyword'])) : '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $checked = isset($_GET['checked']) ? addslashes($_GET['checked']) : '';

    $sortView = (isset($_GET['sortView']) && $_GET['sortView'] == 'ASC') ? 'DESC' : 'ASC';
    $sortComm = (isset($_GET['sortComm']) && $_GET['sortComm'] == 'ASC') ? 'DESC' : 'ASC';
    $sortDate = (isset($_GET['sortDate']) && $_GET['sortDate'] == 'DESC') ? 'ASC' : 'DESC';

    $condition = '';
    if ($sid) {
        $condition = "and sortid=$sid";
    } elseif ($uid) {
        $condition = "and author=$uid";
    } elseif ($checked) {
        $condition = "and checked='$checked'";
    } elseif ($keyword) {
        $condition = "and title like '%$keyword%'";
    }

    $orderBy = ' ORDER BY ';
    if (isset($_GET['sortView'])) {
        $orderBy .= "views $sortView";
    } elseif (isset($_GET['sortComm'])) {
        $orderBy .= "comnum $sortComm";
    } elseif (isset($_GET['sortDate'])) {
        $orderBy .= "date $sortDate";
    } else {
        $orderBy .= 'top DESC, sortop DESC, date DESC';
    }

    $hide_state = $draft ? 'y' : 'n';
    if ($draft) {
        $hide_stae = 'y';
        $sorturl = '&draft=1';
    } else {
        $hide_stae = 'n';
        $sorturl = '';
    }

    $logNum = $goodsModel->getProductNum($hide_state, $condition, 'product', 1);
    $logs = $goodsModel->getProductForAdmin($condition . $orderBy, $hide_state, $page);
    $sorts = $CACHE->readCache('sort');

    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($logNum, Option::get('admin_article_perpage_num'), $page, "goods.php?{$subPage}&page=");

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once View::getAdmView('goods');
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action == 'del') {
    $draft = Input::getIntVar('draft');
    $id = Input::getIntVar('id');
    $isRm = Input::getIntVar('rm');

    LoginAuth::checkToken();
    if ($draft || $isRm) {
        $goodsModel->deleteProduct($id);
        doAction('del_product', $id);
    } else {
        $goodsModel->hideSwitch($id, 'y');
    }
    $CACHE->updateCache();
    emDirect("./goods.php?&active_del=1&draft=$draft");
}

if ($action == 'operate_goods') {
    $operate = Input::requestStrVar('operate');
    $draft = Input::postIntVar('draft');
    $logs = Input::postIntArray('blog');
    $sort = Input::postIntVar('sort');
    $author = Input::postIntVar('author');
    $id = Input::requestNumVar('id');

    LoginAuth::checkToken();

    if (!$operate) {
        emDirect("./goods.php?draft=$draft&error_b=1");
    }
    if (empty($logs) && empty($id)) {
        emDirect("./goods.php?draft=$draft&error_a=1");
    }

    switch ($operate) {
        case 'del':
            foreach ($logs as $val) {
                doAction('before_del_product', $val);
                $goodsModel->deleteProduct($val);
                doAction('del_product', $val);
            }
            $CACHE->updateCache();
            emDirect("./goods.php?draft=1&active_del=1&draft=$draft");
            break;
        case 'top':
            foreach ($logs as $val) {
                $goodsModel->updateLog(array('top' => 'y'), $val);
            }
            emDirect("./goods.php?active_up=1&draft=$draft");
            break;
        case 'sortop':
            foreach ($logs as $val) {
                $goodsModel->updateLog(array('sortop' => 'y'), $val);
            }
            emDirect("./goods.php?active_up=1&draft=$draft");
            break;
        case 'notop':
            foreach ($logs as $val) {
                $goodsModel->updateLog(array('top' => 'n', 'sortop' => 'n'), $val);
            }
            emDirect("./goods.php?active_down=1&draft=$draft");
            break;
        case 'hide':
            foreach ($logs as $val) {
                $goodsModel->hideSwitch($val, 'y');
            }
            $CACHE->updateCache();
            emDirect("./goods.php?active_hide=1&draft=$draft");
            break;
        case 'pub':
            foreach ($logs as $val) {
                $goodsModel->hideSwitch($val, 'n');
                if (User::haveEditPermission()) {
                    $goodsModel->checkSwitch($val, 'y');
                }
            }
            $CACHE->updateCache();
            emDirect("./goods.php?draft=1&active_post=1&draft=$draft");
            break;
        case 'move':
            foreach ($logs as $val) {
                $goodsModel->checkEditable($val);
                $goodsModel->updateLog(array('sortid' => $sort), $val);
            }
            $CACHE->updateCache(array('sort', 'logsort'));
            emDirect("./goods.php?active_move=1&draft=$draft");
            break;
        case 'change_author':
            if (!User::haveEditPermission()) {
                emMsg('权限不足！', './');
            }
            foreach ($logs as $val) {
                $goodsModel->updateLog(array('author' => $author), $val);
            }
            $CACHE->updateCache('sta');
            emDirect("./goods.php?active_change_author=1&draft=$draft");
            break;
        case 'check':
            if (!User::haveEditPermission()) {
                emMsg('权限不足！', './');
            }
            if ($logs) {
                foreach ($logs as $id) {
                    $goodsModel->checkSwitch($id, 'y');
                }
            } else {
                $goodsModel->checkSwitch($id, 'y');
            }
            $CACHE->updateCache();
            emDirect("./goods.php?active_ck=1&draft=$draft");
            break;
        case 'uncheck':
            if (!User::haveEditPermission()) {
                emMsg('权限不足！', './');
            }
            if ($logs) {
                $feedback = '';
                foreach ($logs as $id) {
                    $goodsModel->unCheck($id, $feedback);
                }
            } else {
                $id = Input::postIntVar('id');
                $feedback = Input::postStrVar('feedback');
                $goodsModel->unCheck($id, $feedback);
            }
            $CACHE->updateCache();
            emDirect("./goods.php?active_unck=1&draft=$draft");
            break;
    }
}

if ($action === 'release') {
    $blogData = [
        'type_id' => 0,
        'goods_type' => 0,
        'is_sku' => 0,
        'goods_id'    => -1,
        'title'    => '',
        'content'  => '',
        'excerpt'  => '',
        'alias'    => '',
        'sortid'   => -1,
        'type'     => 'blog',
        'password' => '',
        'hide'     => '',
        'author'   => UID,
        'cover'    => '',
        'link'     => '',
        'template' => '',
    ];



    extract($blogData);

    $isdraft = false;
    $containerTitle = User::haveEditPermission() ? '发新商品' : '发布' . Option::get('posts_name');
    $orig_date = '';
    $sorts = $CACHE->readCache('sort');
    $is_top = '';
    $is_sortop = '';
    $postDate = date('Y-m-d H:i');
    $mediaSorts = $MediaSort_Model->getSorts();
    $customTemplates = $Template_Model->getCustomTemplates('log');

    if (!Register::isRegLocal() && $sta_cache['lognum'] > 50) {
        emDirect("auth.php?error_product=1");
    }

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once(View::getAdmView('goods_release'));
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action === 'edit') {
    $goods_id = Input::getIntVar('id');

    $goodsModel->checkEditable($goods_id);
    $blogData = $goodsModel->getOneProductForAdmin($goods_id);
    extract($blogData);

    $isdraft = $hide == 'y' ? true : false;
    $postsName = User::isAdmin() ? '商品' : Option::get('posts_name');
    $containerTitle = $isdraft ? '编辑草稿' : '编辑' . $postsName;
    $postDate = date('Y-m-d H:i', $date);
    $sorts = $CACHE->readCache('sort');



    $mediaSorts = $MediaSort_Model->getSorts();

    $customTemplates = $Template_Model->getCustomTemplates('log');

    $is_top = $top == 'y' ? 'checked="checked"' : '';
    $is_sortop = $sortop == 'y' ? 'checked="checked"' : '';

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once(View::getAdmView('goods_release'));
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action == 'upload_cover') {
    $ret = uploadCropImg();
    Output::ok($ret['file_info']['file_path']);
}


if($action == 'sku_data'){
    $goods_id = Input::getIntVar('goods_id', -1);
    if($goods_id < 0){
        die(json_encode(['code' => 200, 'data' => [], 'msg' => 'ok']));
    }
    $product_specification = $goodsModel->getProductSpecificationForAdmin($goods_id);
    die(json_encode(['code' => 200, 'data' => $product_specification, 'msg' => 'ok']));
    print_r($data);

}

/**
 * 获取商品类型
 */
if($action == 'goods_type_data'){

    $db = Database::getInstance();

    $sql = "SELECT id, name as title FROM `" . DB_PREFIX . "goods_type` ORDER BY id DESC";

    $result = $db->query($sql);

    $data = [];

    while ($row = $db->fetch_array($result)) {
        $row['title'] = htmlspecialchars($row['title']);
        $data[] = $row;
    }

    die(json_encode(['code' => 200, 'data' => $data, 'msg' => 'ok']));
}

if($action == 'attr_spec_data'){


    $goods_type_id = Input::getIntVar('goods_type_id');

    $goods_id = Input::getIntVar('goods_id', -1);

    $db = Database::getInstance();
    $sql = "SELECT id, title FROM `" . DB_PREFIX . "sku_attr` where type_id='{$goods_type_id}' ORDER BY id ASC";
    $result = $db->query($sql);
    $specification = [];

    while ($row = $db->fetch_array($result)) {
        $row['title'] = htmlspecialchars($row['title']);
        $specification[] = $row;
    }

    $sql = "SELECT * FROM `" . DB_PREFIX . "goods_sku` where goods_id={$goods_id}";
    $result = $db->query($sql);
    $product_specification = [];
    while ($row = $db->fetch_array($result)) {
        $product_specification[] = $row;
    }

    if(!empty($specification)){
        $specification_ids = array_column($specification, 'id');
        $sql = "SELECT * FROM `" . DB_PREFIX . "sku_value` where attr_id in(" . implode(',', $specification_ids) . ") ORDER BY id ASC";
        $result = $db->query($sql);
        $specification_value = [];
        while ($row = $db->fetch_array($result)) {
            $row['title'] = htmlspecialchars($row['name']);
            $specification_value[] = $row;
        }

        foreach($specification as $key => $val){
            $specification[$key]['options'] = [];
            $specification[$key]['value'] = [];
            foreach($specification_value as $v){
                foreach($product_specification as $vs){
                    $spec = explode('-', $vs['specification']);
                    if(in_array($v['id'], $spec)){
                        $specification[$key]['value'][] = $v['id'];
                    }
                }
                if($val['id'] == $v['attr_id']){
                    $specification[$key]['options'][] = [
                        'id' => $v['id'],
                        'title' => $v['title']
                    ];
                }
            }
        }
    }



    die(json_encode(['code' => 200, 'data' => [
        'attribute' => $specification,
        'spec' => $specification
    ], 'msg' => 'ok']));

}

/**
 * 创建规格
 */
if($action == 'create_spec'){

    $specification = Input::getStrVar('title');
    $goods_type_id = Input::getIntVar('goods_type_id');

    $kItem = ['type_id', 'title'];
    $dItem = [$goods_type_id, $specification];
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";

    $db = Database::getInstance();

    $sql = "select COUNT(*) AS total from " . DB_PREFIX . "sku_attr where type_id='{$goods_type_id}' and title='{$specification}'";
    $is = $db->once_fetch_array($sql);
    if($is['total'] > 0){
        die(json_encode(['code' => 400, 'msg' => '规格已存在', 'data' => []]));
    }

    $sql = "INSERT INTO " . DB_PREFIX . "sku_attr ($field) VALUES ($values)";
    $db->query($sql);
    $specification_id = $db->insert_id();

    die(json_encode(['code' => 200, 'data' => [
        'id' => $specification_id
    ], 'msg' => 'ok']));


}

if($action == 'create_spec_value'){
    $name = Input::postStrVar('title');
    $specification_id = Input::getIntVar('spec_id');

    $kItem = ['specification_id', 'name'];
    $dItem = [$specification_id, $name];
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";

    $db = Database::getInstance();

    $sql = "select COUNT(*) AS total from " . DB_PREFIX . "sku_value where attr_id='{$specification_id}' and name='{$name}'";
    $is = $db->once_fetch_array($sql);
    if($is['total'] > 0){
        die(json_encode(['code' => 400, 'msg' => '规格值已存在', 'data' => []]));
    }

    $sql = "INSERT INTO " . DB_PREFIX . "sku_value ($field) VALUES ($values)";
    $db->query($sql);
    $specification_value_id = $db->insert_id();

    die(json_encode(['code' => 200, 'data' => [
        'id' => $specification_value_id
    ], 'msg' => 'ok']));
}