<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

//require_once 'globals.php';
require_once '../init.php';

$orderModel = new Order_Model();
$Sort_Model = new Sort_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

$sta_cache = $CACHE->readCache('sta');
$user_cache = $CACHE->readCache('user');
$action = Input::getStrVar('action');

// 订单列表
if (empty($action)) {

    if(isset($user_cache[UID]['role'])){
        $role = $user_cache[UID]['role'];
        $role_name = User::getRoleName($role, UID);
    }
    loginAuth::checkLogin(NULL, 'user');
    User::checkRolePermission();


    $tab = 'member';

    $page = Input::getIntVar('page', 1);
    $orderNum = $orderModel->getUserOrderNum();
    $order = $orderModel->getUserOrderForHome($page);
    $sorts = $CACHE->readCache('sort');

//    d($order);die;

    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($orderNum, Option::get('admin_article_perpage_num'), $page, "order.php?{$subPage}&page=");


    $GLOBALS['mode_payment'] = [];
    doAction('mode_payment');

    if(isset($GLOBALS['mode_payment'][0])){
        $GLOBALS['mode_payment'][0]['active'] = true;
    }

    $mode_payment = $GLOBALS['mode_payment'];

//    d($mode_payment); die;

    include View::getUserView('header');
    require_once View::getUserView('order');
    include View::getUserView('footer');
    View::output();
}
// 订单列表
if ($action == 'search') {

    $tab = 'search';

    $type = Input::getStrVar('type');
    $pwd = Input::getStrVar('pwd');
    if(empty($type) || empty($pwd)){
        include View::getUserView('header');
        require_once View::getUserView('order');
        include View::getUserView('footer');
        View::output();
    }

    $page = Input::getIntVar('page', 1);
    $orderNum = $orderModel->getYoukeOrderNum($type, $pwd);
    $order = $orderModel->getYoukeOrderForHome($page, $type, $pwd);


    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($orderNum, Option::get('admin_article_perpage_num'), $page, "order.php?{$subPage}&page=");


    $GLOBALS['mode_payment'] = [];
    doAction('mode_payment');

    if(isset($GLOBALS['mode_payment'][0])){
        $GLOBALS['mode_payment'][0]['active'] = true;
    }

    $mode_payment = $GLOBALS['mode_payment'];

//    d($mode_payment); die;

    include View::getUserView('header');
    require_once View::getUserView('order');
    include View::getUserView('footer');
    View::output();
}

// 查看卡密
if($action == 'sdk'){
    $id = Input::getIntVar('id'); // 子订单ID
    $data = $orderModel->getOrderSdk($id); // 获取订单卡密

//    d($data);die;

    $out_trade_no = Input::getStrVar('out_trade_no');

    $order = $orderModel->getOrderInfo($out_trade_no);


    $order_id = $data['order_id'];
    if($order_id != $order['id']){
        emMsg('非法请求！');
    }

    $data = $data['sdk'];



    include View::getUserView('header');
    require_once View::getUserView('sdk');
    include View::getUserView('footer');
    View::output();

}

