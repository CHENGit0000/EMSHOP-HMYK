<?php
/**
 * product save and update
 * @package EBSHOP
 * @link https://www.wanghe.life
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

if (empty($_POST)) {
    exit;
}

$goodsModel = new Goods_Model();
$Tag_Model = new Tag_Model();

$title = Input::postStrVar('title');
$postDate = isset($_POST['postdate']) ? strtotime(trim($_POST['postdate'])) : time();
$sort = Input::postIntVar('sort', -1);
$tagstring = isset($_POST['tag']) ? strip_tags(addslashes(trim($_POST['tag']))) : '';
$content = Input::postStrVar('product_content');
$alias = Input::postStrVar('alias');
$top = Input::postStrVar('top', 'n');
$sortop = Input::postStrVar('sortop', 'n');
$allow_remark = Input::postStrVar('allow_remark', 'n');
$password = Input::postStrVar('password');
$template = Input::postStrVar('template');
$cover = Input::postStrVar('cover');
$link = Input::postStrVar('link');
$author = isset($_POST['author']) && User::haveEditPermission() ? (int)trim($_POST['author']) : UID;
$ishide = Input::postStrVar('ishide', 'y');
$goods_id = Input::postIntVar('as_logid', -1); //自动保存为草稿的文章id
$pubPost = Input::postStrVar('pubPost'); // 是否直接发布文章，而非保存草稿

$is_sku = Input::postIntVar('is_attribute');
$sku = Input::postStrArray('skus');
$price = Input::postStrVar('price', 0);
$market_price = Input::postStrVar('market_price', 0);
$cost_price = Input::postStrVar('cost_price', 0);
$stock = Input::postStrVar('stock');
$type_id = Input::postIntVar('product_type', 0);
$goods_type = Input::postIntVar('goods_type');






if ($pubPost) {
    $ishide = 'n';
}

if (!empty($alias)) {
    $logalias_cache = $CACHE->readCache('logalias');
    $alias = $goodsModel->checkAlias($alias, $logalias_cache, $goods_id);
}

//管理员发文不审核,注册用户受开关控制
$checked = Option::get('ischkarticle') == 'y' && !User::haveEditPermission() ? 'n' : 'y';

$productData = [
    'is_sku' => $is_sku,
    'goods_type' => $goods_type,
    'type_id' => $type_id,
    'title'        => $title,
    'alias'        => $alias,
    'content'      => $content,
    'cover'        => $cover,
    'author'       => $author,
    'sortid'       => $sort,
    'date'         => $postDate,
    'top '         => $top,
    'sortop '      => $sortop,
    'allow_remark' => $allow_remark,
    'hide'         => $ishide,
    'checked'      => $checked,
    'password'     => $password,
    'link'         => $link,
    'template'     => $template,
];


//echo '<pre>'; print_r($productData);die;

if (User::isWriter()) {
    $count = $goodsModel->getPostCountByUid(UID, time() - 3600 * 24);
    $post_per_day = Option::get('posts_per_day');
    if ($count >= $post_per_day) {
        emDirect("./profuct.php?error_post_per_day=1");
    }
}

doMultiAction('pre_save_product', $productData, $productData);

if ($goods_id > 0) {
    $goodsModel->updateProduct($productData, $goods_id);
    $Tag_Model->updateTag($tagstring, $goods_id);
} else {
    $goods_id = $goodsModel->addProduct($productData);
    $Tag_Model->addTag($tagstring, $goods_id);
}


if($is_sku){ // 多规格
    $goodsModel->deleteProductSpecification($goods_id);
    $goods_sku = [];
    foreach($sku as $key => $val){
        $goods_sku[] = [
            'goods_id' => $goods_id,
            'specification' => $key,
            'price' => $val['price'] * 100,
            'market_price' => $val['market_price'] * 100,
            'cost_price' => empty($val['cost_price']) ? -1 : $val['cost_price'] * 100,
        ];
    }
    $goodsModel->insertProductSpecification($goods_id, $goods_sku);
}else{ // 单规格
    $goodsModel->deleteProductSpecification($goods_id);
    $goods_sku = [];
    $goods_sku[] = [
        'goods_id' => $goods_id,
        'specification' => 0,
        'price' => $price * 100,
        'market_price' => $market_price * 100,
        'cost_price' => $cost_price * 100,
        'stock' => $stock
    ];
    $goodsModel->insertProductSpecification($goods_id, $goods_sku);
}

$CACHE->updateProductCache();

doAction('save_product', $goods_id, $pubPost, $productData);

// 异步保存
if ($action === 'autosave') {
    exit('autosave_gid:' . $goods_id . '_');
}

// 保存草稿
if ($ishide === 'y') {
    emDirect("./goods.php?draft=1&active_savedraft=1");
}

// 产品（草稿）公开发布
if ($pubPost) {
    if (!User::haveEditPermission()) {
        notice::sendNewPostMail($title, $goods_id);
    }
    emDirect("./goods.php?active_post=1");
}

// 编辑产品（保存并返回）
$page = $goodsModel->getPageOffset($postDate, Option::get('admin_article_perpage_num'));
emDirect("./goods.php?active_savelog=1&page=" . $page);
