<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';

$goodsModel = new Goods_Model();
$stockModel = new Stock_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

if (empty($action)) {
	
	$page = Input::getIntVar('page', 1);

    $stockNum = $stockModel->getStockNum();
    $list = $stockModel->getStockForAdmin($page);
    $sorts = $CACHE->readCache('sort');

    $subPage = '';
    foreach ($_GET as $key => $val) {
        $subPage .= $key != 'page' ? "&$key=$val" : '';
    }
    $pageurl = pagination($stockNum, Option::get('admin_article_perpage_num'), $page, "stock.php?{$subPage}&page=");

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once View::getAdmView('stock');
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action == 'del') {
    $draft = Input::getIntVar('draft');
    $id = Input::getIntVar('id');
    $isRm = Input::getIntVar('rm');

    LoginAuth::checkToken();
    if ($draft || $isRm) {
        $goodsModel->deleteProduct($id);
        doAction('del_product', $id);
    } else {
        $goodsModel->hideSwitch($id, 'y');
    }
    $CACHE->updateCache();
    emDirect("./goods.php?&active_del=1&draft=$draft");
}


if ($action === 'add') {
    $goods_id = Input::postIntVar('goods_id', null);
    if($goods_id){
        $timestamp = time();

//        d($_POST);die;

        $goodsData = $goodsModel->getOneProductForAdmin($goods_id);
        $skus = Input::postStrArray('skus');

        if($goodsData['is_sku'] == 0){
//            d($goodsData);die;
            if($goodsData['goods_type'] == 2){
                $data = [
                    'goods_id' => $goods_id,
                    'sku' => null,
                    'content' => Input::postStrVar('content', null),
                    'create_time' => $timestamp,
                    'quantity' => Input::postIntVar('quantity', 0),
                    'goods_type' => $goodsData['goods_type'],
					'uniqid' => uniqid()
                ];
                $stockModel->deleteStock("goods_id={$goods_id} and (sku is null or sku = '') and goods_type = 2");
                $stockModel->addStock($data);
            }
            if($goodsData['goods_type'] == 1){
                $data = [
                    'goods_id' => $goods_id,
                    'sku' => null,
                    'content' => null,
                    'create_time' => $timestamp,
                    'quantity' => Input::postIntVar('quantity', 0),
                    'goods_type' => $goodsData['goods_type'],
					'uniqid' => uniqid()
                ];
                $stockModel->deleteStock("goods_id={$goods_id} and (sku is null or sku = '') and goods_type = 1");
                $stockModel->addStock($data);
            }
            if($goodsData['goods_type'] == 0){
                $stock = Input::postStrVar('stock_content');
                $stock = array_filter(explode("\r\n", $stock));
                if(!empty($stock)){
                    foreach($stock as $v){
                        $data = [
                            'goods_id' => $goods_id,
                            'sku' => null,
                            'content' => $v,
                            'create_time' => $timestamp,
                            'quantity' => 1,
                            'goods_type' => $goodsData['goods_type'],
							'uniqid' => uniqid()
                        ];
                        $stockModel->addStock($data);
                    }
                }
            }
        }
        if($goodsData['is_sku'] == 1){
            if($goodsData['goods_type'] == 2){
                $stockModel->deleteStock("goods_id={$goods_id} and (sku is not null or sku <> '') and goods_type = 2");
                foreach($skus as $key => $val){
                    if(!empty($val['stock_number']) && !empty($val['stock_content'])){
                        $data = [
                            'goods_id' => $goods_id,
                            'sku' => $key,
                            'content' => $val['stock_content'],
                            'create_time' => $timestamp,
                            'quantity' => $val['stock_number'],
                            'goods_type' => $goodsData['goods_type'],
							'uniqid' => uniqid()
                        ];

                        $stockModel->addStock($data);
                    }
                }
            }
            if($goodsData['goods_type'] == 1){
                foreach($skus as $key => $val){
                    if(!empty($val['stock_quantity'])){
                        $data = [
                            'goods_id' => $goods_id,
                            'sku' => $key,
                            'create_time' => $timestamp,
                            'quantity' => $val['stock_quantity'],
                            'goods_type' => $goodsData['goods_type'],
							'uniqid' => uniqid()
                        ];
                        $stockModel->addStock($data);
                    }
                }
            }
            if($goodsData['goods_type'] == 0){
                foreach($skus as $key => $val){
                    $stock = array_filter(explode("\r\n", $val['stock_sdk']));
                    if(!empty($stock)){
                        foreach($stock as $v){
                            $data = [
                                'goods_id' => $goods_id,
                                'sku' => $key,
                                'content' => $v,
                                'create_time' => $timestamp,
                                'quantity' => 1,
                                'goods_type' => $goodsData['goods_type'],
								'uniqid' => uniqid()
                            ];
                            $stockModel->addStock($data);
                        }
                    }
                }
            }
        }


        emDirect("./stock.php?&action=add&goods_id={$goods_id}&save=1");
    }


    $goods_id = Input::getIntVar('goods_id', -1);
    $goodsData = $goodsModel->getOneProductForAdmin($goods_id);
//    d($goodsData);
    extract($goodsData);

    $customTemplates = $Template_Model->getCustomTemplates('log');

    if (!Register::isRegLocal() && $sta_cache['lognum'] > 50) {
        emDirect("auth.php?error_product=1");
    }

    $db = Database::getInstance();
    $sql = "SELECT id, title FROM `" . DB_PREFIX . "sku_attr` where type_id='{$type_id}' ORDER BY id ASC";
    $result = $db->query($sql);
    $specification = [];

    while ($row = $db->fetch_array($result)) {
        $row['title'] = htmlspecialchars($row['title']);
        $specification[] = $row;
    }

    $sql = "SELECT * FROM `" . DB_PREFIX . "goods_sku` where goods_id={$goods_id}";
    $result = $db->query($sql);
    $product_specification = [];
    while ($row = $db->fetch_array($result)) {
        $product_specification[] = $row;
    }


    if(!empty($specification)){
        $specification_ids = array_column($specification, 'id');
        $sql = "SELECT * FROM `" . DB_PREFIX . "sku_value` where attr_id in(" . implode(',', $specification_ids) . ") ORDER BY id ASC";
        $result = $db->query($sql);
        $specification_value = [];
        while ($row = $db->fetch_array($result)) {
            $row['title'] = htmlspecialchars($row['name']);
            $specification_value[] = $row;
        }

        foreach($specification as $key => $val){
            $specification[$key]['options'] = [];
            $specification[$key]['value'] = [];
            foreach($specification_value as $v){
                foreach($product_specification as $vs){
                    $spec = explode('-', $vs['specification']);
                    if(in_array($v['id'], $spec)){
                        $specification[$key]['value'][] = $v['id'];
                    }
                }
                if($val['id'] == $v['attr_id']){
                    $specification[$key]['options'][] = [
                        'id' => $v['id'],
                        'title' => $v['title']
                    ];
                }
            }
        }
    }

    if($goodsData['is_sku'] == 0){
        if($goodsData['goods_type'] == 2){
            $sql = "select * from " . DB_PREFIX . "stock where goods_id={$goodsData['id']} and goods_type=2";
            $res = $db->query($sql);
            $row = $db->fetch_array($res);
            $stock_quantity = $row['quantity'];
            $stock_content = $row['content'];
        }
        if($goodsData['goods_type'] == 1){
            $sql = "select * from " . DB_PREFIX . "stock where goods_id={$goodsData['id']} and goods_type=1";
            $res = $db->query($sql);
            $row = $db->fetch_array($res);
            $stock_quantity = $row['quantity'];
        }
    }


    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once(View::getAdmView('stock_add'));
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}

if ($action === 'edit') {
    $goods_id = Input::getIntVar('id');

    $goodsModel->checkEditable($goods_id);
    $blogData = $goodsModel->getOneProductForAdmin($goods_id);
    extract($blogData);

    $isdraft = $hide == 'y' ? true : false;
    $postsName = User::isAdmin() ? '商品' : Option::get('posts_name');
    $containerTitle = $isdraft ? '编辑草稿' : '编辑' . $postsName;
    $postDate = date('Y-m-d H:i', $date);
    $sorts = $CACHE->readCache('sort');



    $mediaSorts = $MediaSort_Model->getSorts();

    $customTemplates = $Template_Model->getCustomTemplates('log');

    $is_top = $top == 'y' ? 'checked="checked"' : '';
    $is_sortop = $sortop == 'y' ? 'checked="checked"' : '';

    include View::getAdmView(User::haveEditPermission() ? 'header' : 'uc_header');
    require_once(View::getAdmView('stock_add'));
    include View::getAdmView(User::haveEditPermission() ? 'footer' : 'uc_footer');
    View::output();
}