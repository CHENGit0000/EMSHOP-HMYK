<?php
defined('EM_ROOT') || exit('access denied!');
?>
<ol class="breadcrumb" style="padding-left: 10px; padding-top: 10px;">
    <li><a href="./">控制台</a></li>
    <li><a href="./goods.php">商品管理</a></li>
    <li class="active">库存管理</li>
</ol>
<div class="card shadow mb-4">
    <div class="card-body">
        <form action="goods.php?action=operate_goods" method="post" name="form_log" id="form_log">
            <input type="hidden" name="draft" value="<?= $draft ?>">
            <div>
                <table class="table table-bordered table-striped table-hover datatable no-footer">
                    <thead>
                    <tr>
                        <th><input type="checkbox" id="checkAllItem"/></th>
                        <th>商品名称</th>
                        <th>库存类型</th>
                        <th>库存内容</th>
                        <th style="width: 120px;">操作</th>
                    </tr>
                    </thead>
                    <tbody class="checkboxContainer">
                    <?php foreach ($list as $key => $value): ?>
                        <tr>
                            <td style="width: 20px;"><input type="checkbox" name="uniqid[]" value="<?= $value['uniqid'] ?>" class="ids"/></td>
                            <td><?= $value['title'] ?></td>
                            <td><?= goodsTypeText($value['goods_type']) ?></td>
							<td><?= $value['content'] ?></td>
                            <td>
                                <a href="stock.php?action=add&goods_id=<?= $value['uniqid'] ?>">编辑</a>
                                <a href="javascript: eb_confirm(<?= $value['uniqid'] ?>, 'goods', '<?= LoginAuth::genToken() ?>');" class="badge badge-danger">删除</a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
        </form>
        <div class="page"><?= $pageurl ?> </div>
    </div>
</div>

<script>
    $(function () {
        $("#menu-goods").attr('class', 'has-list open in');
        $("#menu-stock-list").addClass('active');
        setTimeout(hideActived, 3600);
    });
</script>
