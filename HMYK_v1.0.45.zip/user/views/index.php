<?php defined('EM_ROOT') || exit('access denied!'); ?>

<script>
    $(function () {
        $('#menu-index').addClass('active');
    });
</script>