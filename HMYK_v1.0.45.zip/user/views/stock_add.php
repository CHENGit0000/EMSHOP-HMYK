<?php defined('EM_ROOT') || exit('access denied!'); ?>
<style>
    #fairy-sku-table th, #fairy-sku-table td, #fairy-sku-table td input.layui-input{
        text-align: center;
    }
    #fairy-sku-table td input.layui-input{
        padding-left: 0;
    }
</style>
<div id="msg" class="fixed-top alert" style="display: none"></div>
<ol class="breadcrumb" style="padding-left: 10px; padding-top: 10px;">
    <li><a href="./">控制台</a></li>
    <li><a href="./goods.php">商品管理</a></li>
    <li><a href="./stock.php">库存管理</a></li>
    <li class="active">添加库存 - <?= $title ?></li>
</ol>

<form action="stock.php?action=add" method="post" enctype="multipart/form-data" id="addgoods" name="addgoods" class="">
    <?php if($is_sku == 0 && $goods_type == 0): ?>
        <textarea name="stock_content" class="form-control" rows="13" placeholder="不同卡密之间使用回车键换行"></textarea>
    <?php endif ?>

    <?php if($is_sku == 0 && $goods_type == 2): ?>
    <div class="form-group">
        <label for="exampleInputAccount1">库存数量</label>
        <input type="number" class="form-control" name="quantity" value="<?= $stock_quantity ?>">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">固定通用卡密</label>
        <input type="type" class="form-control" name="content" value="<?= $stock_content ?>">
    </div>
    <?php endif ?>

    <?php if($goods_type == 1): ?>
        <div class="form-group">
            <label for="exampleInputAccount1">库存数量</label>
            <input type="number" class="form-control" name="quantity" value="<?= $stock_quantity ?>">
        </div>
    <?php endif ?>

    <div class="col-xs-12 col-md-12">
        <input type="hidden" name="goods_id" value="<?= $goods_id ?>"/>
        <div class="fairy-form" style="margin: 20px 0;">
            <!--商品规格选项-->
            <div id="fairy-is-attribute"></div>
            <!--商品类型选择-->
            <div id="fairy-product-type"></div>
            <!--商品属性表-->
            <div id="fairy-attribute-table"></div>
            <!--商品规格表-->
            <div id="fairy-spec-table"></div>
            <!--商品库存表-->
            <div id="fairy-sku-table"></div>
        </div>

    </div>
    <div class="col-xs-12 col-md-12">
        <div id="post_button">
            <input type="submit" value="保存" class="btn btn-success btn-sm"/>
        </div>
        <div class="shadow-sm p-3 bg-white rounded" id="post_side">

        </div>
    </div>
</form>

<div class="modal fade" id="addStock">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">关闭</span></button>
                <h4 class="modal-title">添加卡密</h4>
            </div>
            <div class="modal-body">
                <textarea id="stock-content" class="form-control" rows="13" placeholder="不同卡密之间使用回车键换行"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-primary" id="btn-save">保存</button>
            </div>
        </div>
    </div>
</div>



<script src="./views/components/lay-module/sortable.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
<script src="./views/components/lay-module/skuTable.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>

<?php if(isset($_GET['save'])){ ?>
<script>
    $(function(){
        new $.zui.Messager('库存添加成功', {
            type: 'success'
        }).show();
    })

</script>
<?php } ?>
<script>
    let id = 0;
    $('#addStock').on('shown.zui.modal', function(event) {
        id = event.relatedTarget.id;

    })
    $('#btn-save').click(function(){
        let content = $('#stock-content').val();
        $('textarea[name="' + id + '"]').val(content);
        $('#stock-content').val(null);
        $('#addStock').modal('hide')
    })

    var goods_type = "<?= $goods_type ?>"


    if(goods_type == 0){ // 独立卡密
        var multipleSkuTableConfig = {
            thead: [
                {title: '库存', icon: ''},
            ],
            tbody: [
                {type: "sdk", field: "stock_sdk", value: '', verify: 'required|number', reqtext: '库存不能为空'},
            ]
        }
        var singleSkuTableConfig = {
            thead: [
                {title: '销售价(元)', icon: 'icon-edit'},
                {title: '市场价(元)', icon: 'icon-edit'},
                {title: '成本价(元)', icon: 'icon-edit'},
                {title: '库存', icon: ''},
            ],
                tbody: [
                {type: 'input', field: 'price', value: '', verify: 'required|number', reqtext: '销售价不能为空'},
                {type: 'input', field: 'market_price', value: '', verify: 'required|number', reqtext: '市场价不能为空'},
                {type: 'input', field: 'cost_price', value: '', verify: 'required|number', reqtext: '成本价不能为空'},
                {type: "sdk", field: "stock_sdk", value: '', verify: 'required|number', reqtext: '库存不能为空'},
            ]
        }
    }
    if(goods_type == 1){ // 虚拟服务类型
        var multipleSkuTableConfig = {
            thead: [
                {title: '库存数量', icon: ''},
            ],
            tbody: [
                {type: "input", field: "stock_quantity", value: '', verify: 'required|number', reqtext: '库存不能为空'},
            ]
        }
        var singleSkuTableConfig = {
            thead: [
                {title: '销售价(元)', icon: 'icon-edit'},
                {title: '市场价(元)', icon: 'icon-edit'},
                {title: '成本价(元)', icon: 'icon-edit'},
                {title: '库存', icon: ''},
            ],
            tbody: [
                {type: 'input', field: 'price', value: '', verify: 'required|number', reqtext: '销售价不能为空'},
                {type: 'input', field: 'market_price', value: '', verify: 'required|number', reqtext: '市场价不能为空'},
                {type: 'input', field: 'cost_price', value: '', verify: 'required|number', reqtext: '成本价不能为空'},
                {type: "sdk", field: "stock_sdk", value: '', verify: 'required|number', reqtext: '库存不能为空'},
            ]
        }
    }
    if(goods_type == 2){ // 固定卡密
        var multipleSkuTableConfig = {
            thead: [
                {title: '库存数量', icon: ''},
                {title: '固定通用卡密', icon: ''},
            ],
            tbody: [
                {type: "input", field: "stock_number", value: '', verify: 'required|number', reqtext: '不能为空'},
                {type: "input", field: "stock_content", value: '', verify: 'required|number', reqtext: '不能为空'},
            ]
        }
        var singleSkuTableConfig = {
            thead: [
                {title: '销售价(元)', icon: 'icon-edit'},
                {title: '市场价(元)', icon: 'icon-edit'},
                {title: '成本价(元)', icon: 'icon-edit'},
                {title: '库存', icon: ''},
            ],
            tbody: [
                {type: 'input', field: 'price', value: '', verify: 'required|number', reqtext: '销售价不能为空'},
                {type: 'input', field: 'market_price', value: '', verify: 'required|number', reqtext: '市场价不能为空'},
                {type: 'input', field: 'cost_price', value: '', verify: 'required|number', reqtext: '成本价不能为空'},
                {type: "sdk", field: "stock_sdk", value: '', verify: 'required|number', reqtext: '库存不能为空'},
            ]
        }
    }



    var form = $('#addgoods');



    var options = {
        operate: 'stock',
        isAttributeElemId: 'fairy-is-attribute',
        productTypeElemId: 'fairy-product-type',
        attributeTableElemId: 'fairy-attribute-table',
        specTableElemId: 'fairy-spec-table',
        skuTableElemId: 'fairy-sku-table',
        //商品规格模式 0单规格 1多规格
        mode: "<?php echo $is_sku ?>",
        //是否开启sku表行合并
        rowspan: true,
        //图片上传接口
        uploadUrl: './json/upload.json',
        //获取商品类型接口
        productTypeUrl: 'goods.php?action=goods_type_data',
        //获取商品类型下的规格和属性接口
        attrSpecUrl: 'goods.php?action=attr_spec_data',
        //创建规格接口
        specCreateUrl: 'goods.php?action=create_spec',
        //删除规格接口
        specDeleteUrl: './json/specDelete.json',
        //创建规格值接口
        specValueCreateUrl: 'goods.php?action=create_spec_value',
        //删除规格值接口
        specValueDeleteUrl: './json/specValueDelete.json',
        //单规格SKU表配置
        singleSkuTableConfig: singleSkuTableConfig,
        //多规格SKU表配置
        multipleSkuTableConfig: multipleSkuTableConfig,
        // ========================================== 回显时相关配置参数 ========================================== //
        //商品id
        goods_id: "<?php echo $goods_id ?>",
        //商品类型id
        productTypeId: "<?= isset($type_id) ? $type_id : '' ?>",
        //sku数据接口
        skuDataUrl: 'goods.php?action=sku_data',
    }

        var skuTableObj = new SkuTable(options);

        form.on('submit', function (data) {

            console.log(data)

            //获取表单数据
            console.log(data.field);

            // return false;

            if (skuTableObj.getMode() == 0) {
                //单规格
                // layer.alert(JSON.stringify(data.field), {title: '提交的数据'});
            } else {
                //多规格
                var state = Object.keys(data.field).some(function (item, index, array) {
                    return item.startsWith('skus');
                });
                // state ? layer.alert(JSON.stringify(data.field), {title: '提交的数据'}) : layer.msg('sku表数据不能为空', {icon: 5, anim: 6});
            }

            return true;
        });
    // });

</script>
<script>

    $(function () {
        $("#menu-goods").attr('class', 'has-list open in');
        $("#menu-stock-list").addClass('active');
        setTimeout(hideActived, 3600);


        $('#uncheckModel').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget)
            var id = button.data('id')
            var modal = $(this)
            modal.find('.modal-footer #id').val(id)
        })

    });



</script>
