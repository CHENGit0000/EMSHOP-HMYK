<?php defined('EM_ROOT') || exit('access denied!'); ?>
<!doctype html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name=renderer content=webkit>
    <title>个人中心 - <?= Option::get('blogname') ?></title>

    <link rel="stylesheet" href="../../../admin/views/css/bootstrap.min.css">

    <script src="../../../admin/views/js/jquery.min.3.5.1.js"></script>
    <script src="../../../admin/views/js/bootstrap.bundle.min.4.6.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>

    <link rel="stylesheet" type="text/css" href="../../../admin/views/css/dropzone.css?t=<?= Option::EM_VERSION_TIMESTAMP ?>">
    <link rel="stylesheet" type="text/css" href="../../../admin/views/css/cropper.min.css?t=<?= Option::EM_VERSION_TIMESTAMP ?>">
    <script src="../../../admin/views/js/js.cookie-2.2.1.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="../../../admin/views/js/cropper.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="../../../admin/views/js/common.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="../../../admin/views/components/layer/layer.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <script src="../../../admin/views/components/message.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
    <?php doAction('adm_head') ?>
    <style>
        #top-bar {
            background: #4e73df;
        }

        #top-bar a {
            color: white;
        }
    </style>
</head>
<body class="d-flex flex-column h-100 bg-light">
<div id="editor-md-dialog"></div>
<main class="flex-shrink-0">

    <nav class="navbar navbar-expand-md navbar-dark bg-primary shadow-sm">
        <div class="container">
            <!-- 品牌标识 -->
            <a class="navbar-brand d-flex align-items-center" href="<?= EM_URL ?>">
                <i class="fas fa-shopping-bag mr-2"></i>
                <span><?= subString(Option::get('blogname'), 0, 12) ?></span>
            </a>

            <!-- 移动端菜单按钮 -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- 导航项目 -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <!-- 使用mr-auto让导航项靠左（默认navbar-nav是左对齐，ml-auto会右对齐，这里移除ml-auto并添加mr-auto到容器） -->
                <ul class="navbar-nav mr-auto">
                    <!-- 我的订单 -->
                    <li class="nav-item">
                        <a class="nav-link" href="order.php">
                            <i class="fas fa-box mr-1"></i>
                            我的订单
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
    <div class="container px-1 my-5">
        <div class="row gx-5 justify-content-center">
            <div class="col-lg-12 col-xl-12 col-xxl-12">
