<?php
defined('EM_ROOT') || exit('access denied!');
?>
<style>
    .panel-body .comment:last-child{
        border-bottom: unset;
    }
    .panel-body .comment{
        padding: 0;
    }
</style>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h4 mb-0 text-gray-800">卡密详情</h1>
</div>
<div>
    <div class="panel">
        <div class="panel-heading"></div>
        <div class="panel-body">
            <?php foreach($data as $val): ?>
                <div class="comment">
                    <div class="content">
                        <div class="text"><?= $val['content'] ?></div>
                        <div class="" style="margin-top: 10px;">
                            <!--                            <a class="btn btn-primary btn-sm" href="" data-iframe="?action=sdk&id=--><?php //= $v['id'] ?><!--" data-toggle="modal">查看卡密</a>-->
<!--                            <a href="###"><i class="icon icon-copy"></i> 复制</a>-->
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </div>
</div>

<script>
    $(function () {
        $('#menu-order').addClass('active');
    });
</script>
