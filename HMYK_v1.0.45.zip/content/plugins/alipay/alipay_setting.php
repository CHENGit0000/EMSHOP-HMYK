<?php
defined('EM_ROOT') || exit('access denied!');

function plugin_setting_view() {
    $plugin_storage = Storage::getInstance('alipay');
    $appid = $plugin_storage->getValue('appid');
    $public_key = $plugin_storage->getValue('public_key');
    $private_key = $plugin_storage->getValue('private_key');
    $dm = $plugin_storage->getValue('dm');
    $mb = $plugin_storage->getValue('mb');
    $pc = $plugin_storage->getValue('pc');


    $appid = empty($appid) ? '' : $appid;
    $public_key = empty($public_key) ? '' : $public_key;
    $private_key = empty($private_key) ? '' : $private_key;
    $dm = empty($dm) ? null : $dm;
    $mb = empty($mb) ? null : $mb;
    $pc = empty($pc) ? null : $pc;

    ?>
    <?php if (isset($_GET['succ'])): ?>
        <div class="alert alert-success">hello world !</div>
    <?php endif; ?>

    <div class="panel" style="">
        <div class="panel-body no-padding">
            <ol class="breadcrumb" style="padding: 10px 15px; margin-bottom: 0;">
                <li><a href="./">控制台</a></li>
                <li><a href="./plugin.php">插件管理</a></li>
                <li class="active">配置 - 官方支付宝</li>
            </ol>
        </div>
    </div>

    <div class="panel mt-3">

        <div class="panel-body">

            <div class="alert alert-primary with-icon">
                <div class="content">
                    <span style="">注意事项</span><hr />
                    ① 请根据实际情况开启3种支付方式。<br />
                    ② 请勿开启您未在支付宝官方签约的支付方式。<br />
                    ③ 手机端访问您的网站，优先调用手机网站支付，如未开启手机网站支付则调用当面付。电脑网站支付在手机端无法调用！<br />
                    ④ 电脑端访问您的网站，优先调用电脑网站支付，如未开启电脑网站支付则调用当面付。手机网站支付在电脑端无法调用！
                </div>
            </div>


            <form method="post" id="tips_form" action="./plugin.php?plugin=alipay&action=setting" class="form-horizontal">

                <div class="form-group">
                    <label class="col-sm-2 required">开启</label>
                    <div class="col-md-6 col-sm-10">
                        <label class="checkbox-inline">
                            <input type="checkbox" <?= $dm ? 'checked' : '' ?> name="dm" value="1"> 当面付
                        </label>
                        <label class="checkbox-inline">
                            <input type="checkbox" <?= $mb ? 'checked' : '' ?> name="mb" value="1"> 手机网站支付
                        </label>
                        <label class="checkbox-inline">
                            <input type="checkbox" <?= $pc ? 'checked' : '' ?> name="pc" value="1"> 电脑网站支付
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 required">APPID</label>
                    <div class="col-md-6 col-sm-10">
                        <input type="text" class="form-control" name="appid" value="<?= $appid ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 required">支付宝公钥</label>
                    <div class="col-md-6 col-sm-10">
                        <input type="text" class="form-control" name="public_key" value="<?= $public_key ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 required">应用私钥</label>
                    <div class="col-md-6 col-sm-10">
                        <input type="text" class="form-control" name="private_key" value="<?= $private_key ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <input type="submit" class="btn btn-primary btn-sm mx-2" value="保存">
                    </div>
                </div>
            </form>
        </div>
    </div>


    <script>
        setTimeout(hideActived, 3600);

        $("#menu-plugin").attr('class', 'has-list open in');
        $("#menu-my-plugin").addClass('active');



        // 异步提交表单
        $("#tips_form").submit(function (event) {
            event.preventDefault();
            submitForm("#tips_form");
        });
    </script>
<?php }

function plugin_setting() {
    $appid = Input::postStrVar('appid');
    $public_key = Input::postStrVar('public_key');
    $private_key = Input::postStrVar('private_key');
    $dm = Input::postStrVar('dm');
    $mb = Input::postStrVar('mb');
    $pc = Input::postStrVar('pc');

    $plugin_storage = Storage::getInstance('alipay');
    $plugin_storage->setValue('appid', $appid);
    $plugin_storage->setValue('public_key', $public_key);
    $plugin_storage->setValue('private_key', $private_key);
    $plugin_storage->setValue('dm', $dm);
    $plugin_storage->setValue('mb', $mb);
    $plugin_storage->setValue('pc', $pc);
    Output::ok();
}
