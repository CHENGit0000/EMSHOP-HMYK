<?php
/**
 * 页面底部信息
 */
defined('EM_ROOT') || exit('access denied!');
?>


<footer class="bg-white py-3">
    <div class="container">
        <div class="row">
            <!-- 版权信息 -->
            <div class="col-md-6 text-center text-md-left">
                <small><?= $footer_info ?></small>
                <br>
                <small class="text-muted">
                    <?php
                    if (!empty($icp)) {
                        echo '<a href="https://beian.miit.gov.cn/" target="_blank">' . $icp . '</a>';
                    }
                    ?>
                </small>
                <?php doAction('index_footer') ?>
            </div>
        </div>
    </div>
</footer>
</body>
</html>