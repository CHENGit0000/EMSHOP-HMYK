<?php
/**
 * homepage & article detail
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

class Pay_Controller {

    /**
     * 发起支付
     */
    function index() {

        $CACHE = Cache::getInstance();
        $options_cache = Option::getAll();
        extract($options_cache);
        $out_trade_no = Input::postStrVar('out_trade_no');

        $payment = Input::postStrVar('payment');
        $pay_plugin = Input::postStrVar('pay_plugin');
        $pay_name = Input::postStrVar('pay_name');

//        d($attach_user);die;

        $pwd = Input::postStrVar('pwd');

        $client_ip = getClientIP();

        $plugin_data = [
            'client_ip' => $client_ip
        ];

        doAction('start_pay_before', $plugin_data);

        if($out_trade_no){

            $orderModel = new Order_Model();
            $order_info = $orderModel->getOrderInfo($out_trade_no);
            $params = $orderModel->getOrderList($order_info['id']);
            $order_info['amount'] *= 100;
//            d($order_info); die;


        }else{
            $params = Input::postStrArray('product');
        }

        $db = Database::getInstance();

//        d($params); die;

        $stock_table = DB_PREFIX . 'stock';
        foreach($params as $val){
            $sku = empty($val['sku']) ? '0' : $val['sku'];
            // 查询当前商品的库存数量，并更新商品表的库存字段
            $sql = "SELECT COALESCE(SUM(quantity), 0) AS total_quantity FROM {$stock_table} WHERE goods_id = {$val['goods_id']} and sku = '{$sku}'";
            $res = $db->once_fetch_array($sql);
            $stock_num = $res['total_quantity'];
            if($stock_num < $val['quantity']){
                emMsg('该商品剩余库存量不足，请联系客服人员', 'javascript:window.close();');
            }
        }

        $orderModel = new Order_Model();
        $goodsModel = new Goods_Model();

        if($out_trade_no){
            $order = $orderModel->getOrderInfo($out_trade_no);
            $order_list = $orderModel->getOrderList($order['id']);

//            d($order_list);die;

        }else{
            $timestamp = time();
            $out_trade_no = date('YmdHis', $timestamp) . mt_rand(1000, 9999);


            $order_info = [
                'out_trade_no' => $out_trade_no,
                'payment' => $payment,
                'pay_plugin' => $pay_plugin,
                'create_time' => $timestamp,
                'amount' => 0,
                'expire_time' => $timestamp + 600,
                'pay_name' => $pay_name,
                'client_ip' => getClientIP(),
                'user_id' => UID,
                'pwd' => $pwd
            ];
//        d($order_info); die;
            $order_id = $orderModel->addOrder($order_info);

            $order_list = [];
//d($params);die;
            foreach($params as $val){
                if(empty($val['sku'])){
                    $specification = '';
                    $specification_value = '';
                    $attr_spec = '';
                    $sku = $orderModel->getSku($val['goods_id'], 0);
                }else{
                    $specification_value_data = $orderModel->getSpecificationValue($val['sku']);
                    $specification_value = array_column($specification_value_data, 'name');

                    $specification_ids = array_column($specification_value_data, 'attr_id');
                    $specification_data = $orderModel->getSpecification($specification_ids);
                    $specification = array_column($specification_data, 'title');
                    $sku = $orderModel->getSku($val['goods_id'], $val['sku']);
                    $attr_spec = '';
                    foreach($specification as $k => $v){
                        $attr_spec .= $v . '：' . $specification_value[$k] . '；';
                    }
                }


                $price = $sku['price'] * 100 * $val['quantity'];

                $order_list_insert = [
                    'order_id' => $order_id,
                    'goods_id' => $val['goods_id'],
                    'sku' => $val['sku'],
                    'quantity' => $val['quantity'],
                    'unit_price' => $sku['price'] * 100,
                    'price' => $price,
                    'attr_spec' => $attr_spec,
                    'attach_user' => empty($val['attach_user']) ? null : json_encode($val['attach_user'], JSON_UNESCAPED_UNICODE),
                ];
                $order_info['amount'] += $sku['price'] * 100 * $val['quantity'];
                $orderModel->addOrderList($order_list_insert);

                $order_list[] = $order_list_insert;

            }

            $update = [
                'amount' => $order_info['amount']
            ];

            $orderModel->updateOrderInfo($out_trade_no, $update);
        }



        $pay_func = "pay_{$pay_plugin}";

        // d($order_info);
        // d($order_list);
        // die;



        $scan = $pay_func($order_info, $order_list);



    }


    /**
     * 同步通知
     */
    public function _return(){

        // echo 1;die;

        $orderModel = new Order_Model();

        $out_trade_no = Input::getStrVar('out_trade_no');

        if(empty($out_trade_no)){
            header("location: " . EM_URL . 'user/order.php' . (ISLOGIN ? '' : '?action=search'));
            die;
        }


        $order_info = $orderModel->getOrderInfo($out_trade_no);


        // d($order_info);die;

        $checkFunc = $order_info['pay_plugin'] . "CheckSign";
        $checkSign = $checkFunc('return');


        if($checkSign){ // 验签通过 - 支付成功
            $order_update = [
                'pay_status' => 1,
            ];

            $order = $orderModel->getOrderInfo($checkSign['out_trade_no']);
            if($order['pay_status'] == 1){
                header("location: " . EM_URL . 'user/order.php' . (ISLOGIN ? '' : '?action=search'));
            die;
                echo 'ok'; die; // 重复通知
            }else{
                $res = $orderModel->updateOrderPayStatus($order_info['id'], $order_update); // 修改订单的支付状态

            }


            // 更新订单的支付时间
			$orderModel->updateOrderInfo($checkSign['out_trade_no'], [
                'pay_time' => $checkSign['timestamp'],
                'up_no' => $checkSign['up_no']
            ]);
            // 去发货
            $orderModel->deliver($order_info['id']);

            header("location: " . EM_URL . 'user/order.php' . (ISLOGIN ? '' : '?action=search'));
            die;



        }else{ // 验签失败
            echo '验签失败';
        }
    }



    /**
     * 异步通知
     */
    public function notify(){
        
        
        
 
        $orderModel = new Order_Model();

        $url = $_SERVER['REQUEST_URI'];
        
        // 移除查询参数，只保留路径部分
        $path = parse_url($url, PHP_URL_PATH); // 返回：/action/notify/epay_ali
        
        // 按斜杠分割路径
        $parts = explode('/', trim($path, '/'));
        
        // 获取第三个部分（索引为2）
        $plugin = $parts[2] ?? '';
        
        if($plugin == 'epusdt'){
            $filename = '1111.txt';
            $file = fopen($filename, 'w');
            $bytes_written = fwrite($file, "notify start --------------- \n");
            $bytes_written = fwrite($file, 'post ' .  json_encode($_POST) . " \n");
            $bytes_written = fwrite($file, 'get ' .  json_encode($_GET) . " \n");
        }
        
        
        
        $checkFunc = $plugin . "CheckSign"; 
        
   
        
        
        
        $checkSign = $checkFunc('notify');

        if($checkSign){ // 验签通过 - 支付成功
        
            if($plugin == 'epusdt'){
                $bytes_written = fwrite($file, "验签成功 --------------- \n");
            }

  
            $order_info = $orderModel->getOrderInfo($checkSign['out_trade_no']);

            $order_update = [
                'pay_status' => 1,
            ];
            
            $order = $orderModel->getOrderInfo($checkSign['out_trade_no']);
            if($order['pay_status'] == 1){
                echo 'success'; die; // 重复通知
            }else{
                $res = $orderModel->updateOrderPayStatus($order_info['id'], $order_update); // 修改订单的支付状态
            }
			
            // 更新订单的支付时间
            $orderModel->updateOrderInfo($checkSign['out_trade_no'], [
                'pay_time' => $checkSign['timestamp'],
                'up_no' => $checkSign['up_no']
            ]);
            // 去发货
            $orderModel->deliver($order_info['id']);
            echo 'success'; die;

        }else{ // 验签失败
            echo '验签失败';
            if($plugin == 'epusdt'){
                $bytes_written = fwrite($file, "验签失败 --------------- \n");
            }
        }

    }

    /**
     * 补单
     */
    public function repay($out_trade_no){
        $orderModel = new Order_Model();
        $order_info = $orderModel->getOrderInfo($out_trade_no);

//        d($order_info);die;

        $order_update = [
            'pay_status' => 1,
        ];
        $res = $orderModel->updateOrderPayStatus($order_info['id'], $order_update); // 修改订单的支付状态
        if(!$res){ // 重复通知
            emMsg('请勿重复补单，该订单状态为已支付！');
        }
        // 更新订单的支付时间
        $orderModel->updateOrderInfo($out_trade_no, ['pay_time' => time(), 'payment' => $order_info['payment'] . '(补单)']);
        // 去发货
        $orderModel->deliver($order_info['id']);


        emMsg('补单成功');
    }

    /**
     * 验证订单支付状态
     */
    public function isPay(){
        $out_trade_no = Input::postStrVar('out_trade_no');
        $orderModel = new Order_Model();
        $order_info = $orderModel->getOrderInfo($out_trade_no);
        if($order_info['pay_time']){
            die(json_encode([
                'code' => 200, 'msg' => 'Paid', 'data' => [
                    'is_pay' => true
                ]
            ]));
        }else{
            die(json_encode([
                'code' => 200, 'msg' => 'Unpaid', 'data' => [
                    'is_pay' => false
                ]
            ]));
        }
    }



}
